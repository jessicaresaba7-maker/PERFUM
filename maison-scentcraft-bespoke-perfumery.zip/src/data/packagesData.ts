import { PackageTier, AddOnItem, ScentNote } from '../types/perfume';

export const WEDDING_PACKAGES: PackageTier[] = [
  {
    id: 'first-class',
    name: 'First Class Package',
    category: 'wedding-debut',
    subtitle: 'Intimate Atelier Experience for Metro Manila Couples & Debutantes',
    description: 'Our most exclusive fragrance crafting journey featuring an in-person bespoke blending masterclass guided by our master nose.',
    badge: 'Signature Experience',
    maxScents: 3,
    includesFaceToFace: true,
    features: [
      'Face to Face Perfume Making Session (for Metro Manila clients only; maximum of 2 hours)',
      'Personalized Bottle Design, Label, and Packaging tailored to your event coordinates & motif',
      'Maximum of 3 Custom Scents blended live to perfection',
      'Curated Eau de Parfum concentration (25-30% fragrance oils for 12+ hour longevity)',
      'Complimentary consultation on bottle silhouette, cap finishes, and wax stamp branding'
    ],
    basePrice: 18500,
    idealFor: 'Couples, Debutantes, and Mom-to-Be looking for a hands-on sensorial experience'
  },
  {
    id: 'business-class',
    name: 'Business Class Package',
    category: 'wedding-debut',
    subtitle: 'Comprehensive 20-Fragrance Home Atelier Experience',
    description: 'Receive our full discovery library right at your doorstep to test, wear, and select your top 3 signature event scents at your own pace.',
    badge: 'Most Popular',
    maxScents: 3,
    discoverySetCount: 20,
    features: [
      'Discovery Set containing 20 curated artisan scents shipped directly to you',
      'Personalized Bottle Design, Label, and Packaging matching your theme & typography',
      'Maximum of 3 Signature Scents for your celebration gifts & favors',
      'Complimentary digital design mockups with your venue coordinates & love story date',
      'Deluxe textured cotton labeling with smudge-proof gold/silver/ink finish'
    ],
    basePrice: 14500,
    idealFor: 'Clients wanting extensive scent exploration from anywhere in the Philippines'
  },
  {
    id: 'regular-class',
    name: 'Regular Class Package',
    category: 'wedding-debut',
    subtitle: 'Essential Discovery & Timeless Bespoke Bottles',
    description: 'An approachable yet luxurious fragrance package featuring our top 10 bestseller discovery vials and custom designed flacons.',
    badge: 'Essential Charm',
    maxScents: 2,
    discoverySetCount: 10,
    features: [
      'Discovery Set containing 10 bestselling artisan scents',
      'Personalized Bottle Design, Label, and Packaging',
      'Maximum of 2 Signature Scents curated for your event guests',
      'Choice of bottle silhouette with customized event details & location stamp',
      'High-grade glass flacons with fine-mist atomizer pumps'
    ],
    basePrice: 9800,
    idealFor: 'Intimate weddings, delicate debuts, and cozy baby shower gatherings'
  }
];

export const STAG_BACHELORETTE_PACKAGE: PackageTier = {
  id: 'stag-bachelorette',
  name: 'Stag & Bachelorette Package',
  category: 'stag-bachelorette',
  subtitle: 'Bespoke Scent Keepsakes for your Groom Squad & Bride Tribe',
  description: 'Elevate your send-off celebrations with dual customized scent profiles engineered specifically for your bridesmaids and groomsmen.',
  badge: 'Squad Celebration',
  maxScents: 4, // 2 for bridesmaids + 2 for groomsmen
  features: [
    'Premium Personalized Bottle Design, Label, and Packaging with custom crew tags',
    'Maximum of 2 Scents for Bridesmaids (feminine/delicate florals & fresh accords)',
    'Maximum of 2 Scents for Groomsmen (masculine/woody, amber, & invigorating notes)',
    'Customized city or party coordinates (e.g., Boracay, Siargao, Tokyo, Poblacion)',
    'Individually boxed in bespoke slide-out gift sleeves with matte ribbon pull'
  ],
  basePrice: 12000,
  idealFor: 'Bachelorette parties, bridal showers, stag parties, and golf getaway weekends'
};

export const SPECIAL_EVENTS_PACKAGES: PackageTier[] = [
  {
    id: 'events-15-30',
    name: '15 – 30 Pax Tier',
    category: 'special-events',
    subtitle: 'Intimate Gatherings & VIP Dinners',
    description: 'Tailored for close family milestones, executive retreats, intimate birthday celebrations, and boutique launches.',
    minPax: 15,
    maxPax: 30,
    maxScents: 2,
    features: [
      'Complete set of 15–30 personalized bespoke perfume flacons (50ml)',
      'Custom coordinates label, personalized guest name stamping, and luxury box',
      'Up to 2 curated gender-neutral or thematic signature scents',
      'Complimentary fragrance consultation with personalized scent cards',
      'Metro Manila delivery or provincial secure packaging'
    ],
    basePrice: 16500,
    idealFor: 'Private dinners, milestone birthdays, small baptismal celebrations'
  },
  {
    id: 'events-31-50',
    name: '31 – 50 Pax Tier',
    category: 'special-events',
    subtitle: 'Mid-Scale Celebrations & Brand Activations',
    description: 'Ideal for medium wedding guestlists, 18th debuts, milestone anniversaries, and corporate year-end banquets.',
    minPax: 31,
    maxPax: 50,
    maxScents: 3,
    features: [
      'Complete set of 31–50 personalized bespoke perfume flacons (50ml)',
      'Custom coordinates design featuring event coordinates, hashtag & motif',
      'Up to 3 curated signature scents with customized scent descriptors',
      'Free event signage template & tasting menu card for guest tables',
      'Options for mixed caps (Obsidian Black, Pearl White, or Brushed Gold)'
    ],
    basePrice: 25000,
    idealFor: 'Medium-sized weddings, lavish debuts, and company anniversary galas'
  },
  {
    id: 'events-51-80',
    name: '51 – 80 Pax Tier',
    category: 'special-events',
    subtitle: 'Grand Celebrations & Corporate Launches',
    description: 'Designed for ballroom receptions, corporate brand activations, and large society debuts requiring refined souvenirs.',
    minPax: 51,
    maxPax: 80,
    maxScents: 3,
    features: [
      'Complete set of 51–80 personalized bespoke perfume flacons (50ml)',
      'Full bespoke branding on front label, seal, and back ingredient registry',
      'Up to 3 signature event fragrance blends',
      'Dedicated atelier production manager & quality batch inspection',
      'Customized batch numbering (e.g., Bottle No. 01/80)'
    ],
    basePrice: 38500,
    idealFor: 'Full wedding receptions, corporate conferences, and grand debuts'
  },
  {
    id: 'events-81-100',
    name: '81 – 100 Pax Tier',
    category: 'special-events',
    subtitle: 'Large Scale Banquets & Milestone Festivities',
    description: 'Comprehensive high-volume package with volume-tiered pricing, priority production, and customized discovery set sample kit.',
    minPax: 81,
    maxPax: 100,
    maxScents: 4,
    features: [
      'Complete set of 81–100 personalized bespoke perfume flacons (50ml)',
      'Free 10-scent pre-event discovery kit sent to event hosts for selection',
      'Up to 4 custom fragrance blend variations (His, Hers, Universal, Fresh)',
      'Luxury packaging with custom embossed foil coordinates crest',
      'Free Metro Manila delivery directly to your event venue coordinator'
    ],
    basePrice: 47000,
    idealFor: 'Large luxury weddings, multi-day conventions, and high-profile parties'
  },
  {
    id: 'events-100-plus',
    name: '100 Pax & Above Tier',
    category: 'special-events',
    subtitle: 'Mega Events, Conventions & Brand Partnerships',
    description: 'Our enterprise tier for 100+ to 1,000+ guests. Includes tiered volume privileges, custom bottle shapes, and on-site fragrance bar options.',
    minPax: 100,
    maxPax: 500,
    maxScents: 4,
    features: [
      '100+ bespoke bottles (custom tiered bulk pricing per bottle)',
      'Option for On-Site Live Perfume Bar Setup with Scent Baristas (Metro Manila)',
      'Full customization: bottle shapes, labels, wax seals, and velvet bags',
      'Dedicated fragrance formulation tailored to your brand or event narrative',
      'Priority express scheduling & sample proofs before mass bottling'
    ],
    basePrice: 55000,
    idealFor: 'Major corporate events, national conferences, luxury hospitality gifting'
  }
];

export const ADD_ON_ITEMS: AddOnItem[] = [
  {
    id: 'bride-groom-perfume',
    name: 'Bride & Groom Perfume Duo',
    subtitle: '2 × 100ml Statement Keepsake Flacons',
    description: 'Two substantial 100ml statement bottles formulated with the highest concentration of rare fragrance oils. A precious olfactory heirloom from your wedding day.',
    features: [
      '2 × 100ml Heavy Glass Statement Perfume Flacons',
      'Premium Personalized Bottle Design, Label, and Packaging',
      'Customized wedding venue coordinates & wedding vow inscription option',
      'Luxury keepsake hardbox lined with velvet & bespoke wax seal'
    ],
    price: 4500,
    unit: 'per pair (2 bottles)',
    iconName: 'HeartHandshake'
  },
  {
    id: 'entourage-gift',
    name: 'Entourage Gift Sets',
    subtitle: 'Curated for Bridesmaids & Groomsmen',
    description: 'Say thank you to the core people standing by your side with personalized bottles bearing their individual roles and hand-picked scent profiles.',
    features: [
      'Premium Personalized Bottle Design, Label, and Packaging',
      'Maximum of 2 Scents for Bridesmaids (Delicate, luminous floral bouquets)',
      'Maximum of 2 Scents for Groomsmen (Sophisticated woods, spices & fresh citrus)',
      'Individual personalized name tags & bridesmaid/groomsman title on the label'
    ],
    price: 680,
    unit: 'per bottle (min. 6 bottles)',
    iconName: 'Gift'
  }
];

export const SCENT_LIBRARY: ScentNote[] = [
  {
    id: 'tokyo-blossom',
    name: 'Tokyo Coordinates',
    category: 'Floral',
    description: 'Inspired by spring mornings along the Meguro River. Delicate, ephemeral, and gently uplifting.',
    topNotes: ['Cherry Blossom', 'Fuji Apple', 'White Tea'],
    heartNotes: ['Neroli Blossom', 'Magnolia', 'Pink Peony'],
    baseNotes: ['White Musk', 'Blonde Woods', 'Clean Linen'],
    vibe: 'Soft, airy, romantic, and clean'
  },
  {
    id: 'kyoto-sanctuary',
    name: 'Kyoto Sanctuary',
    category: 'Woody',
    description: 'Atmospheric cedar shrines, sacred hinoki wood, and drifting morning incense mist.',
    topNotes: ['Cypress Leaf', 'Bergamot', 'Cardamom'],
    heartNotes: ['Hinoki Wood', 'Smoked Vetiver', 'Orris'],
    baseNotes: ['Cedarwood', 'Atlas Cedar', 'Dry Amber'],
    vibe: 'Grounding, serene, architectural, and elegant'
  },
  {
    id: 'santorini-azure',
    name: 'Santorini Azure',
    category: 'Aquatic',
    description: 'Sun-bleached whitewashed cliffs meeting sparkling Aegean seawater and wild seaside herbs.',
    topNotes: ['Sea Salt Mist', 'Lemon Zest', 'Calabrian Bergamot'],
    heartNotes: ['Neroli', 'Coastal Rosemary', 'White Cyclamen'],
    baseNotes: ['Driftwood', 'Mineral Amber', 'Crisp Cotton'],
    vibe: 'Invigorating, sunlit, refreshing, and oceanic'
  },
  {
    id: 'paris-atelier',
    name: 'Parisian Atelier',
    category: 'Oriental & Amber',
    description: 'Intimate evening warmth inside a classic Saint-Germain boutique with vintage velvet and warm amber lights.',
    topNotes: ['Pink Pepper', 'Sweet Mandarin', 'Spiced Fig'],
    heartNotes: ['Turkish Rose', 'Orris Butter', 'Bourbon Vanilla'],
    baseNotes: ['Golden Amber', 'Tonka Bean', 'Sandalwood'],
    vibe: 'Sophisticated, sensual, decadent, and memorable'
  },
  {
    id: 'tagaytay-mist',
    name: 'Tagaytay Ridge Mist',
    category: 'Citrus & Fresh',
    description: 'Cool highland morning breeze overlooking pine trees, lemongrass fields, and crisp dawn air.',
    topNotes: ['Green Bergamot', 'Crisp Lemongrass', 'Crushed Mint'],
    heartNotes: ['Highland Pine', 'White Freesia', 'Eucalyptus'],
    baseNotes: ['Cashmeran', 'Clean Moss', 'Soft Musk'],
    vibe: 'Cooling, revitalizing, natural, and crisp'
  },
  {
    id: 'provence-lavande',
    name: 'Provence Golden Hour',
    category: 'Floral',
    description: 'Endless rolling lavender fields kissed by late afternoon French sunlight and honeyed breezes.',
    topNotes: ['French Lavender', 'Wild Thyme', 'Bergamot'],
    heartNotes: ['Honeyed Neroli', 'English Pear', 'Heliotrope'],
    baseNotes: ['Creamy Sandalwood', 'White Cedar', 'Vanilla Husk'],
    vibe: 'Comforting, poetic, warm floral, and balanced'
  },
  {
    id: 'manila-sol',
    name: 'Intramuros Solstice',
    category: 'Woody',
    description: 'Sunlit cobblestones, antique narra wood corridors, and blossoming night-blooming sampaguita.',
    topNotes: ['Sampaguita Jasmine', 'Calamansi Rind', 'Ginger Lily'],
    heartNotes: ['Ylang-Ylang', 'White Orchid', 'Nutmeg'],
    baseNotes: ['Aged Narra Wood', 'Patchouli', 'Benzoin'],
    vibe: 'Warm, heritage-rich, romantic, and nostalgic'
  },
  {
    id: 'vanilla-bourbon',
    name: 'Cacao & Bourbon Vanilla',
    category: 'Gourmand & Warm',
    description: 'Artisanal single-origin dark cocoa steeped in toasted vanilla orchid and golden cane sugar.',
    topNotes: ['Toasted Almond', 'Spiced Rum', 'Sweet Orange'],
    heartNotes: ['Dark Cocoa', 'Warm Honey', 'Clove Bud'],
    baseNotes: ['Bourbon Vanilla Pod', 'Amber Resin', 'Smoked Vetiver'],
    vibe: 'Warm, cozy, gourmand, and luxurious'
  }
];

export const PHILIPPINES_COORDINATE_PRESETS = [
  { name: 'Manila Cathedral (Intramuros)', coords: "14° 35' 29.5\" N  120° 58' 25.1\" E", city: 'MANILA' },
  { name: 'San Agustin Church (Old Manila)', coords: "14° 35' 20.9\" N  120° 58' 31.8\" E", city: 'INTRAMUROS' },
  { name: 'Tagaytay Ridge (Highlands)', coords: "14° 06' 54.2\" N  120° 57' 41.6\" E", city: 'TAGAYTAY' },
  { name: 'Bonifacio Global City (BGC)', coords: "14° 33' 01.4\" N  121° 03' 04.2\" E", city: 'BGC TAGUIG' },
  { name: 'Makati Financial District', coords: "14° 33' 18.0\" N  121° 01' 12.0\" E", city: 'MAKATI' },
  { name: 'Boracay White Beach', coords: "11° 58' 04.8\" N  121° 55' 27.6\" E", city: 'BORACAY' },
  { name: 'El Nido Bacuit Bay', coords: "11° 11' 28.3\" N  119° 23' 14.7\" E", city: 'EL NIDO' },
  { name: 'Tokyo Shibuya Sky', coords: "35° 41' 01.5\" N  139° 46' 02.2\" E", city: 'TOKYO' },
  { name: 'Parisian Rive Gauche', coords: "48° 51' 24.1\" N  2° 20' 54.3\" E", city: 'PARIS' }
];
