import React, { useState } from 'react';
import { PHILIPPINES_COORDINATE_PRESETS } from '../data/packagesData';
import { Sparkles, MapPin, Check, RefreshCw, Send } from 'lucide-react';

interface InteractiveBottlePreviewProps {
  onUseInQuote: (config: {
    title: string;
    city: string;
    coords: string;
    palette: string;
    scents: string[];
  }) => void;
}

const AVAILABLE_SCENT_ACCORDS = [
  'Cherry Blossom',
  'White Musk',
  'Neroli Blossom',
  'Hinoki Wood',
  'Smoked Vetiver',
  'Sea Salt & Sage',
  'Sampaguita Jasmine',
  'Tagaytay Pine',
  'Bourbon Vanilla',
  'English Pear',
  'Bergamot Rind',
  'Amber Resin'
];

export const InteractiveBottlePreview: React.FC<InteractiveBottlePreviewProps> = ({ onUseInQuote }) => {
  const [labelTitle, setLabelTitle] = useState('MARCO & SOFIA');
  const [cityOrEvent, setCityOrEvent] = useState('MANILA CATHEDRAL');
  const [coordsText, setCoordsText] = useState('14° 35\' 29.5" N  120° 58\' 25.1" E');
  const [selectedPalette, setSelectedPalette] = useState<'sakura-pink' | 'pearl-white' | 'stone-greige' | 'mist-blue' | 'ink-black'>('pearl-white');
  const [capColor, setCapColor] = useState<'matte-black' | 'pearl-white' | 'champagne-gold'>('matte-black');
  const [selectedNotes, setSelectedNotes] = useState<string[]>(['Cherry Blossom', 'White Musk', 'Neroli Blossom']);
  const [stampCity, setStampCity] = useState('MANILA');

  const toggleScent = (scent: string) => {
    if (selectedNotes.includes(scent)) {
      if (selectedNotes.length > 1) {
        setSelectedNotes(selectedNotes.filter(s => s !== scent));
      }
    } else {
      if (selectedNotes.length < 3) {
        setSelectedNotes([...selectedNotes, scent]);
      } else {
        // replace last
        setSelectedNotes([selectedNotes[0], selectedNotes[1], scent]);
      }
    }
  };

  const handleApplyPreset = (preset: typeof PHILIPPINES_COORDINATE_PRESETS[0]) => {
    setCoordsText(preset.coords);
    setCityOrEvent(preset.name);
    setStampCity(preset.city);
  };

  // Palette styling mapping
  const paletteStyles = {
    'sakura-pink': {
      bg: 'bg-[#FAF3F2]',
      border: 'border-[#E4CAC7]',
      labelBg: 'bg-[#FCF7F6]',
      accentText: 'text-[#B87A77]',
      badgeBg: 'bg-[#F2DBD9]',
      glow: 'shadow-[0_20px_50px_rgba(232,200,198,0.4)]'
    },
    'pearl-white': {
      bg: 'bg-[#FBF9F5]',
      border: 'border-[#E5DFD4]',
      labelBg: 'bg-[#FFFFFF]',
      accentText: 'text-[#696359]',
      badgeBg: 'bg-[#F0ECE3]',
      glow: 'shadow-[0_20px_50px_rgba(215,205,190,0.35)]'
    },
    'stone-greige': {
      bg: 'bg-[#F4F1ED]',
      border: 'border-[#D9D3CA]',
      labelBg: 'bg-[#FAF8F5]',
      accentText: 'text-[#7A746B]',
      badgeBg: 'bg-[#E5DFD6]',
      glow: 'shadow-[0_20px_50px_rgba(190,182,170,0.3)]'
    },
    'mist-blue': {
      bg: 'bg-[#F2F6F8]',
      border: 'border-[#CDDCE3]',
      labelBg: 'bg-[#FFFFFF]',
      accentText: 'text-[#5E7989]',
      badgeBg: 'bg-[#DFEAF0]',
      glow: 'shadow-[0_20px_50px_rgba(134,156,169,0.35)]'
    },
    'ink-black': {
      bg: 'bg-[#24262A]',
      border: 'border-[#3D4046]',
      labelBg: 'bg-[#1C1D20]',
      accentText: 'text-[#E5DFD4]',
      badgeBg: 'bg-[#31343A]',
      glow: 'shadow-[0_20px_50px_rgba(20,20,25,0.45)]'
    }
  };

  const currentTheme = paletteStyles[selectedPalette];
  const isDarkTheme = selectedPalette === 'ink-black';

  return (
    <section id="bottle-studio" className="py-16 sm:py-24 bg-[#F7F4EE] border-b border-[#E8E2D6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs tracking-[0.25em] uppercase text-[#708794] font-medium mb-2 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#B89694]" />
            <span>Interactive Bespoke Studio</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-serif-title font-medium text-[#1F2124] tracking-tight">
            Preview Your Custom Coordinates & Bottle Label
          </h2>
          <p className="text-xs sm:text-sm text-[#5C574F] mt-2 font-light">
            Every bottle is tailored with your choice of GPS coordinates, event title, custom typography, 
            and your handpicked 2 to 3 signature fragrance notes.
          </p>
        </div>

        {/* Studio Workspace: 2-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Left Column: Live Rendered Flacon Card */}
          <div className="lg:col-span-6 flex flex-col items-center">
            
            <div className={`w-full max-w-md rounded-xs border p-6 sm:p-8 transition-all duration-500 ${currentTheme.bg} ${currentTheme.border} ${currentTheme.glow}`}>
              
              {/* Bottle Simulator Container */}
              <div className="relative mx-auto w-64 sm:w-72 flex flex-col items-center pt-2 pb-6">
                
                {/* 1. Bottle Cap */}
                <div 
                  className={`w-14 h-12 rounded-t-xs transition-colors duration-300 shadow-sm ${
                    capColor === 'matte-black' 
                      ? 'bg-[#1E2024] border border-[#2E3137]' 
                      : capColor === 'pearl-white'
                      ? 'bg-[#F9F7F3] border border-[#DDD5C7]'
                      : 'bg-[#D4AF37] border border-[#C29D29] bg-gradient-to-b from-[#EED582] to-[#B8952B]'
                  }`}
                />
                
                {/* Cap neck ring */}
                <div className="w-16 h-2 bg-[#D1C9BE] border-x border-[#BCB3A5]"></div>

                {/* 2. Glass Flacon Body */}
                <div className={`relative w-full h-[340px] rounded-xs border ${
                  isDarkTheme ? 'border-[#444852] bg-[#1F2124]' : 'border-[#DFD9CD] bg-white/95'
                } backdrop-blur-md shadow-lg flex flex-col items-center justify-center p-4 overflow-hidden`}>
                  
                  {/* Subtle Glass Reflection Gradient */}
                  <div className="absolute inset-0 bg-gradient-to-r from-white/30 via-transparent to-black/5 pointer-events-none" />
                  
                  {/* Liquid fill illusion */}
                  <div className={`absolute bottom-0 inset-x-0 h-4/5 ${
                    selectedPalette === 'sakura-pink' ? 'bg-[#F7EBEA]/50' :
                    selectedPalette === 'mist-blue' ? 'bg-[#EBF2F5]/50' :
                    'bg-[#FAF8F3]/40'
                  } pointer-events-none`} />

                  {/* 3. The Bespoke Cotton Label */}
                  <div className={`relative z-10 w-[88%] py-6 px-4 text-center rounded-xs transition-colors duration-300 shadow-xs border ${
                    isDarkTheme 
                      ? 'bg-[#1A1B1E] border-[#373A42] text-[#E8E2D6]' 
                      : 'bg-[#FAF8F5] border-[#E0D9CC] text-[#24262A]'
                  }`}>
                    
                    {/* Brand header */}
                    <div className="text-[11px] tracking-[0.28em] uppercase font-light text-[#736E66]">
                      co°rdinates
                    </div>
                    <div className="text-[9px] tracking-[0.35em] uppercase font-normal text-[#8A847C] mb-2">
                      parfum
                    </div>

                    {/* Hairline Divider */}
                    <div className="w-8 h-[1px] bg-[#C5BDAF] mx-auto mb-3" />

                    {/* Custom Title (Couple / Event) */}
                    <div className={`text-base sm:text-lg font-serif-title tracking-[0.16em] uppercase font-semibold truncate px-1 ${
                      isDarkTheme ? 'text-[#FAF6EE]' : 'text-[#1F2124]'
                    }`}>
                      {labelTitle || 'YOUR TITLE'}
                    </div>

                    {/* Venue / City */}
                    <div className="text-[10px] tracking-[0.2em] uppercase text-[#7D776E] mt-0.5 truncate">
                      {cityOrEvent || 'EVENT LOCATION'}
                    </div>

                    {/* GPS Coordinates (Tabular numerals) */}
                    <div className="text-[10px] font-mono tabular-nums tracking-wider text-[#635E56] my-2.5 bg-black/5 dark:bg-white/5 py-0.5 px-1 rounded-2xs inline-block max-w-full truncate">
                      {coordsText}
                    </div>

                    {/* Hairline Divider */}
                    <div className="w-8 h-[1px] bg-[#C5BDAF] mx-auto my-2" />

                    {/* Custom Scent Notes */}
                    <div className="text-[10px] tracking-wide italic text-[#59544C] leading-tight px-2">
                      {selectedNotes.join(' · ')}
                    </div>

                    {/* Volume */}
                    <div className="text-[8px] tracking-[0.2em] uppercase text-[#948D82] mt-3 font-mono">
                      50ml e 1.7 fl.oz.
                    </div>
                  </div>

                  {/* Stamp Seal in corner */}
                  <div className={`absolute top-4 right-4 border border-dashed rounded-full w-12 h-12 flex flex-col items-center justify-center rotate-12 pointer-events-none ${
                    isDarkTheme ? 'border-[#555963] text-[#A6ADB8]' : 'border-[#C2B7A6] text-[#786E61]'
                  }`}>
                    <span className="text-[6px] tracking-widest uppercase font-semibold">{stampCity}</span>
                    <span className="text-[9px] font-serif">特別</span>
                    <span className="text-[5px] tracking-widest uppercase">PARFUM</span>
                  </div>

                </div>

                {/* Base shadow reflection */}
                <div className="w-48 h-3 bg-black/10 rounded-full blur-xs mt-1" />

              </div>

              {/* Quick Status Bar */}
              <div className="mt-4 pt-3 border-t border-[#E3DDD1] flex items-center justify-between text-xs text-[#6B655B]">
                <span className="font-mono text-[11px]">Bespoke Formula: {selectedNotes.length} Accords</span>
                <span className="tracking-wider uppercase text-[10px] font-semibold text-[#8A7969]">
                  Eau de Parfum (28%)
                </span>
              </div>

            </div>

            {/* Action to transfer this design into quote request */}
            <button
              onClick={() => onUseInQuote({
                title: labelTitle,
                city: cityOrEvent,
                coords: coordsText,
                palette: selectedPalette,
                scents: selectedNotes
              })}
              className="mt-4 w-full max-w-md py-3 px-4 bg-[#1F2124] text-white text-xs tracking-[0.16em] uppercase font-semibold rounded-xs hover:bg-[#32363D] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <Send className="w-3.5 h-3.5 text-[#E5C5C2]" />
              <span>Use This Design In My Quote</span>
            </button>
          </div>

          {/* Right Column: Customization Controls */}
          <div className="lg:col-span-6 bg-white p-6 sm:p-8 rounded-xs border border-[#E5DFD4] shadow-2xs space-y-6">
            
            {/* Control 1: Event Title & Names */}
            <div>
              <label className="block text-xs tracking-[0.16em] uppercase font-medium text-[#383531] mb-1.5">
                01. Label Title (Couple, Debutante, or Event)
              </label>
              <input
                type="text"
                value={labelTitle}
                maxLength={28}
                onChange={(e) => setLabelTitle(e.target.value.toUpperCase())}
                placeholder="e.g. MARCO & SOFIA / AURELIA AT 18"
                className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124] tracking-wide uppercase"
              />
              <span className="text-[11px] text-[#80796F] mt-1 block">
                Printed in high-contrast luxury serif typeface on textured cotton label.
              </span>
            </div>

            {/* Control 2: Event Venue & GPS Coordinates */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs tracking-[0.16em] uppercase font-medium text-[#383531]">
                  02. Venue Name & GPS Coordinates
                </label>
                <span className="text-[10px] text-[#869CA9] uppercase tracking-wider font-mono">
                  Real GPS Coordinates
                </span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-2">
                <input
                  type="text"
                  value={cityOrEvent}
                  onChange={(e) => setCityOrEvent(e.target.value)}
                  placeholder="e.g. MANILA CATHEDRAL"
                  className="px-3 py-2 text-xs bg-[#FAF8F5] border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124] uppercase"
                />
                <input
                  type="text"
                  value={coordsText}
                  onChange={(e) => setCoordsText(e.target.value)}
                  placeholder={'e.g. 14° 35\' 29.5" N 120° 58\' 25.1" E'}
                  className="px-3 py-2 text-xs font-mono bg-[#FAF8F5] border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
                />
              </div>

              {/* Coordinate Presets Selector */}
              <div className="mt-2 pt-2 border-t border-[#EFEBE4]">
                <span className="text-[10px] uppercase tracking-wider text-[#8A8377] block mb-1.5 font-medium">
                  Popular Philippine & Global Presets:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {PHILIPPINES_COORDINATE_PRESETS.slice(0, 6).map((preset) => (
                    <button
                      key={preset.name}
                      onClick={() => handleApplyPreset(preset)}
                      className="text-[11px] px-2.5 py-1 bg-[#F4EFE7] hover:bg-[#EAE3D6] text-[#4A453E] rounded-xs transition-colors cursor-pointer border border-[#DDD6C8]"
                    >
                      {preset.city}: {preset.name.split(' (')[0]}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Control 3: Motif Theme Palette */}
            <div>
              <label className="block text-xs tracking-[0.16em] uppercase font-medium text-[#383531] mb-2">
                03. Choose Bottle Packaging Motif (From Reference Moodboard)
              </label>
              <div className="grid grid-cols-5 gap-2">
                {[
                  { id: 'sakura-pink', name: 'Sakura', color: '#E8C8C6' },
                  { id: 'pearl-white', name: 'Pearl', color: '#F6F3EE' },
                  { id: 'stone-greige', name: 'Greige', color: '#E1DDD8' },
                  { id: 'mist-blue', name: 'Mist', color: '#869CA9' },
                  { id: 'ink-black', name: 'Ink', color: '#282A2E' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setSelectedPalette(item.id as any)}
                    className={`flex flex-col items-center p-2 rounded-xs border transition-all cursor-pointer ${
                      selectedPalette === item.id 
                        ? 'border-[#1F2124] ring-1 ring-[#1F2124] bg-[#FAF8F5]' 
                        : 'border-[#E0D9CE] hover:border-[#BDB5A7]'
                    }`}
                  >
                    <div 
                      className="w-full h-7 rounded-2xs shadow-2xs border border-black/10" 
                      style={{ backgroundColor: item.color }} 
                    />
                    <span className="text-[10px] tracking-wider uppercase mt-1 text-[#4F4A42] font-medium">
                      {item.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Control 4: Cap Finishes */}
            <div>
              <label className="block text-xs tracking-[0.16em] uppercase font-medium text-[#383531] mb-2">
                04. Flacon Cap Silhouette & Finish
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { id: 'matte-black', label: 'Matte Obsidian', dot: '#1E2024' },
                  { id: 'pearl-white', label: 'Pearl White', dot: '#F9F7F3' },
                  { id: 'champagne-gold', label: 'Champagne Gold', dot: '#D4AF37' }
                ].map((cap) => (
                  <button
                    key={cap.id}
                    onClick={() => setCapColor(cap.id as any)}
                    className={`flex items-center gap-2 p-2.5 rounded-xs border text-left transition-all cursor-pointer ${
                      capColor === cap.id
                        ? 'border-[#1F2124] bg-[#F8F5EE] text-[#1F2124]'
                        : 'border-[#E0D9CD] hover:border-[#BBB2A3] text-[#555047]'
                    }`}
                  >
                    <span 
                      className="w-3.5 h-3.5 rounded-full border border-black/20 shrink-0" 
                      style={{ backgroundColor: cap.dot }} 
                    />
                    <span className="text-xs font-medium truncate">{cap.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Control 5: Select 2 to 3 Signature Fragrance Accords */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs tracking-[0.16em] uppercase font-medium text-[#383531]">
                  05. Select 2 to 3 Scent Accords
                </label>
                <span className="text-[11px] font-mono text-[#7A746B]">
                  {selectedNotes.length}/3 Selected
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pr-1">
                {AVAILABLE_SCENT_ACCORDS.map((accord) => {
                  const isSelected = selectedNotes.includes(accord);
                  return (
                    <button
                      key={accord}
                      onClick={() => toggleScent(accord)}
                      className={`text-xs px-2.5 py-1.5 rounded-xs border transition-all cursor-pointer flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-[#1F2124] text-white border-[#1F2124]'
                          : 'bg-[#FAF8F5] text-[#4A463F] border-[#D8D0C3] hover:border-[#9E9588]'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 text-[#E5C5C2]" />}
                      <span>{accord}</span>
                    </button>
                  );
                })}
              </div>
              <span className="text-[11px] text-[#7D776E] mt-2 block">
                *First Class & Business Class include up to 3 custom scents. Regular Class includes 2 scents.
              </span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
