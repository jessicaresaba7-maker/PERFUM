import React from 'react';
import { ADD_ON_ITEMS } from '../data/packagesData';
import { Check, HeartHandshake, Gift, Plus, Sparkles } from 'lucide-react';

interface AddOnsSectionProps {
  onAddBrideGroomToQuote: () => void;
  onAddEntourageToQuote: () => void;
}

export const AddOnsSection: React.FC<AddOnsSectionProps> = ({
  onAddBrideGroomToQuote,
  onAddEntourageToQuote
}) => {
  return (
    <section id="addons" className="py-16 sm:py-24 bg-[#F5F2EC] border-b border-[#E7E0D3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="text-xs tracking-[0.25em] uppercase text-[#708794] font-medium mb-1.5 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#B89694]" />
            <span>Signature Bespoke Enhancements</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-serif-title font-medium text-[#1F2124] tracking-tight">
            Curated Add-Ons
          </h2>
          <p className="text-xs sm:text-sm text-[#5B564E] mt-2 font-light">
            Elevate your wedding and event favors with dedicated 100ml flacons for the couple 
            and individually personalized gifts for your bridesmaids and groomsmen entourage.
          </p>
        </div>

        {/* 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Card 1: BRIDE AND GROOM PERFUME (2 x 100ml) */}
          <div className="lg:col-span-6 bg-white rounded-xs border border-[#E0D8CB] shadow-sm overflow-hidden flex flex-col justify-between">
            <div>
              {/* Image banner */}
              <div className="relative aspect-16/10 bg-[#EDE7DD] overflow-hidden">
                <img
                  src="/src/assets/images/bride_groom_perfume_duo_1790682994027.jpg"
                  alt="Bride and Groom 2 x 100ml luxury perfume flacons"
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-102"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-[#1F2124]/90 backdrop-blur-xs text-white px-2.5 py-1 text-[10px] tracking-[0.18em] uppercase font-medium">
                  2 × 100ml Duo
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-8 space-y-4">
                <div className="flex items-center justify-between border-b border-[#EFEBE4] pb-3 text-xs text-[#708794]">
                  <span className="font-mono tracking-wider uppercase">STATEMENT FLACONS</span>
                  <span className="font-semibold text-[#8A7969] uppercase tracking-wider">His & Hers Heirloom</span>
                </div>

                <div>
                  <h3 className="text-xl sm:text-2xl font-serif-title font-semibold text-[#1F2124]">
                    Bride & Groom Perfume
                  </h3>
                  <p className="text-xs sm:text-sm text-[#615C54] mt-1 font-light leading-relaxed">
                    Two substantial 100ml statement perfume bottles for the bride and groom. 
                    Personalized with your wedding venue coordinates, wedding vow excerpt, and signature custom scents.
                  </p>
                </div>

                {/* Price */}
                <div className="flex items-baseline gap-1 py-1">
                  <span className="text-xs text-[#787268] font-mono">PHP</span>
                  <span className="text-2xl font-serif-title font-bold text-[#1F2124] tabular-nums">
                    ₱4,500
                  </span>
                  <span className="text-xs text-[#7A746B] ml-1">/ pair (includes 2 × 100ml flacons)</span>
                </div>

                {/* Exact requirements from brief */}
                <div className="space-y-2.5 pt-2">
                  <span className="text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3934] block">
                    Inclusions:
                  </span>
                  <ul className="space-y-2 text-xs text-[#4F4A43]">
                    <li className="flex items-start gap-2.5">
                      <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                      <span>2 × 100ml heavy-base French glass flacons with fine atomizer</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                      <span>Premium Personalized Bottle Design, Label, and Packaging</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                      <span>Choice of matching or contrasting his/hers scents from discovery library</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                      <span>Luxury textured presentation box with silk ribbon and wax seal</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Action */}
            <div className="p-6 sm:p-8 pt-0">
              <button
                onClick={onAddBrideGroomToQuote}
                className="w-full py-3 px-4 bg-[#1F2124] text-white text-xs tracking-[0.16em] uppercase font-semibold rounded-xs hover:bg-[#34373E] transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <Plus className="w-3.5 h-3.5 text-[#E5C5C2]" />
                <span>Add Bride & Groom Duo to Quote</span>
              </button>
            </div>
          </div>

          {/* Card 2: ENTOURAGE GIFT */}
          <div className="lg:col-span-6 bg-white rounded-xs border border-[#E0D8CB] shadow-sm overflow-hidden flex flex-col justify-between">
            <div className="p-6 sm:p-8 space-y-4">
              
              <div className="flex items-center justify-between border-b border-[#EFEBE4] pb-3 text-xs text-[#708794]">
                <span className="font-mono tracking-wider uppercase">ENTOURAGE SUITE</span>
                <span className="font-semibold text-[#8A7969] uppercase tracking-wider">Bridesmaids & Groomsmen</span>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-serif-title font-semibold text-[#1F2124]">
                  Entourage Gift Bottles
                </h3>
                <p className="text-xs sm:text-sm text-[#615C54] mt-1 font-light leading-relaxed">
                  Gift your bridesmaids, groomsmen, maid of honor, and best man with individual bespoke perfumes 
                  tailored specifically to their role in your love story.
                </p>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-1 py-1">
                <span className="text-xs text-[#787268] font-mono">PHP</span>
                <span className="text-2xl font-serif-title font-bold text-[#1F2124] tabular-nums">
                  ₱680
                </span>
                <span className="text-xs text-[#7A746B] ml-1">/ bottle (custom bulk discounts available)</span>
              </div>

              {/* Exact requirements from brief */}
              <div className="space-y-2.5 pt-2">
                <span className="text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3934] block">
                  Inclusions & Specifications:
                </span>
                <ul className="space-y-2 text-xs text-[#4F4A43]">
                  <li className="flex items-start gap-2.5">
                    <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                    <span>Premium Personalized Bottle Design, Label, and Packaging</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                    <span>Maximum of 2 Scents for Bridesmaids (Delicate florale & radiant musks)</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                    <span>Maximum of 2 Scents for Groomsmen (Crisp aromatics, cedarwood & amber)</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                    <span>Customized recipient name & bridal role printed on individual box sleeves</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                    <span>Choice of cap finish matching your bridal motif (Sakura, Pearl, or Obsidian)</span>
                  </li>
                </ul>
              </div>

              {/* Role preview pills */}
              <div className="p-3.5 bg-[#FAF8F5] rounded-xs border border-[#E9E3D8] text-xs text-[#615C53]">
                <span className="text-[10px] tracking-wider uppercase font-semibold text-[#7D776D] block mb-1">
                  Popular Entourage Titles Included:
                </span>
                <div className="text-[11px] leading-relaxed">
                  Maid of Honor · Best Man · Bridesmaids · Groomsmen · Principal Sponsors · Secondary Sponsors
                </div>
              </div>

            </div>

            {/* Action */}
            <div className="p-6 sm:p-8 pt-0">
              <button
                onClick={onAddEntourageToQuote}
                className="w-full py-3 px-4 bg-white text-[#1F2124] border border-[#D5CDC1] hover:border-[#1F2124] text-xs tracking-[0.16em] uppercase font-semibold rounded-xs transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5 text-[#708794]" />
                <span>Configure Entourage Gift Sets</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
