import React, { useState } from 'react';
import { Menu, X, Sparkles, FileText, Phone } from 'lucide-react';

interface NavbarProps {
  onOpenQuote: () => void;
  onOpenInquiry: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenQuote, onOpenInquiry }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/90 backdrop-blur-md border-b border-[#E8E2D8] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        
        {/* Zone 1: Single element wordmark */}
        <a 
          href="#" 
          className="text-xl sm:text-2xl font-serif-title tracking-[0.22em] text-[#1F2124] uppercase font-semibold hover:opacity-80 transition-opacity"
        >
          co°rdinates <span className="text-xs font-sans-body tracking-[0.3em] font-normal lowercase text-[#708794]">parfum</span>
        </a>

        {/* Zone 2: 4–6 text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-xs tracking-[0.16em] uppercase font-medium text-[#4A4742]">
          <button 
            onClick={() => scrollTo('packages')} 
            className="hover:text-[#1F2124] transition-colors cursor-pointer py-1"
          >
            Packages
          </button>
          <button 
            onClick={() => scrollTo('addons')} 
            className="hover:text-[#1F2124] transition-colors cursor-pointer py-1"
          >
            Add-Ons
          </button>
          <button 
            onClick={() => scrollTo('special-events')} 
            className="hover:text-[#1F2124] transition-colors cursor-pointer py-1"
          >
            Special Events
          </button>
          <button 
            onClick={() => scrollTo('bottle-studio')} 
            className="hover:text-[#1F2124] transition-colors cursor-pointer py-1"
          >
            Customizer Studio
          </button>
          <button 
            onClick={() => scrollTo('discovery')} 
            className="hover:text-[#1F2124] transition-colors cursor-pointer py-1"
          >
            Scent Library
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenQuote}
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs tracking-[0.14em] uppercase font-semibold text-[#1F2124] bg-white border border-[#D5CDC1] hover:border-[#1F2124] transition-colors shadow-2xs whitespace-nowrap cursor-pointer rounded-xs"
          >
            <FileText className="w-3.5 h-3.5 text-[#708794]" />
            Instant Quote
          </button>
          
          <button
            onClick={onOpenInquiry}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs tracking-[0.14em] uppercase font-semibold text-white bg-[#1F2124] hover:bg-[#34373C] transition-colors shadow-xs whitespace-nowrap cursor-pointer rounded-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#E5C5C2]" />
            Book Session
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#2C2926] hover:text-black focus:outline-none cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E8E2D8] bg-[#FAF8F5] px-6 py-6 space-y-4 shadow-lg animate-in fade-in duration-150">
          <div className="flex flex-col space-y-3 text-xs tracking-[0.2em] uppercase font-medium text-[#4A4742]">
            <button 
              onClick={() => scrollTo('packages')} 
              className="text-left py-2 border-b border-[#ECE7DE] hover:text-[#1F2124]"
            >
              Wedding & Celebration Packages
            </button>
            <button 
              onClick={() => scrollTo('addons')} 
              className="text-left py-2 border-b border-[#ECE7DE] hover:text-[#1F2124]"
            >
              Bride & Groom + Entourage Add-Ons
            </button>
            <button 
              onClick={() => scrollTo('special-events')} 
              className="text-left py-2 border-b border-[#ECE7DE] hover:text-[#1F2124]"
            >
              Special Events (15 to 100+ Pax)
            </button>
            <button 
              onClick={() => scrollTo('bottle-studio')} 
              className="text-left py-2 border-b border-[#ECE7DE] hover:text-[#1F2124]"
            >
              Coordinates Label Customizer
            </button>
            <button 
              onClick={() => scrollTo('discovery')} 
              className="text-left py-2 border-b border-[#ECE7DE] hover:text-[#1F2124]"
            >
              Artisan Scent Library
            </button>
          </div>

          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenQuote(); }}
              className="w-full py-2.5 text-center text-xs tracking-[0.14em] uppercase font-medium text-[#1F2124] bg-white border border-[#D5CDC1] rounded-xs"
            >
              Calculate Custom Quote
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenInquiry(); }}
              className="w-full py-2.5 text-center text-xs tracking-[0.14em] uppercase font-semibold text-white bg-[#1F2124] rounded-xs"
            >
              Book Scent Session / Inquire
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
