import React from 'react';
import { Compass, Sparkles, MapPin, ArrowRight } from 'lucide-react';

interface HeroProps {
  onExplorePackages: () => void;
  onOpenStudio: () => void;
  onOpenQuote: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExplorePackages, onOpenStudio, onOpenQuote }) => {
  return (
    <section className="relative overflow-hidden bg-[#FAF8F5] pt-10 pb-16 sm:py-20 lg:py-24 border-b border-[#EAE4D9]">
      {/* Subtle organic background glow */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-40 -right-40 w-96 h-96 rounded-full bg-[#E5C5C2]/30 blur-3xl"
      />
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute top-1/2 -left-32 w-80 h-80 rounded-full bg-[#8AA0AD]/20 blur-3xl"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Sub-header Tagline */}
        <div className="flex items-center gap-3 text-xs tracking-[0.25em] uppercase text-[#708794] font-medium mb-4">
          <Compass className="w-3.5 h-3.5 text-[#B7A99A]" />
          <span>Scents Inspired By Places & Memorable Milestones</span>
        </div>

        {/* Grid: Left Editorial Pitch, Right Luxury Visual Asset */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif-title font-medium leading-[1.12] text-[#1F2124] text-balance">
              Every unforgettable celebration has its own <span className="italic font-normal text-[#8A7969]">coordinates.</span>
            </h1>

            <p className="text-sm sm:text-base text-[#5A564F] leading-relaxed max-w-xl font-light">
              Bespoke fragrance atelier for weddings, debuts, baby showers, and grand celebrations. 
              From intimate face-to-face scent making sessions in Metro Manila to nationwide discovery sets—we bottle 
              your exact date, location coordinates, and cherished memories into haute parfumerie favors.
            </p>

            {/* Quiet Metadata Bar (No-pill discipline) */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-xs tracking-[0.12em] text-[#69645C] pt-2 border-t border-[#EAE4D9]">
              <span>Metro Manila Atelier</span>
              <span aria-hidden="true" className="text-[#C5BDB2]">·</span>
              <span>10 & 20 Scent Discovery Sets</span>
              <span aria-hidden="true" className="text-[#C5BDB2]">·</span>
              <span>Personalized Bottle & Packaging</span>
              <span aria-hidden="true" className="text-[#C5BDB2]">·</span>
              <span>15 to 100+ Pax Souvenirs</span>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-4">
              <button
                onClick={onExplorePackages}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs tracking-[0.16em] uppercase font-semibold text-white bg-[#1F2124] hover:bg-[#32353A] transition-colors shadow-xs rounded-xs cursor-pointer"
              >
                <span>View All Packages</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onOpenStudio}
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-xs tracking-[0.16em] uppercase font-semibold text-[#1F2124] bg-white border border-[#D5CDC1] hover:border-[#1F2124] transition-colors shadow-2xs rounded-xs cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#B89694]" />
                <span>Customize Your Bottle</span>
              </button>

              <button
                onClick={onOpenQuote}
                className="inline-flex items-center justify-center text-xs tracking-[0.14em] uppercase text-[#6E675D] hover:text-[#1F2124] underline underline-offset-4 px-2 py-2 cursor-pointer transition-colors"
              >
                Instant Pricing Estimate ₱
              </button>
            </div>

            {/* Palette swatch indicator inspired by the user's uploaded moodboard */}
            <div className="pt-6">
              <span className="block text-[11px] tracking-[0.2em] uppercase text-[#888278] mb-2 font-medium">
                Signature Event Palette
              </span>
              <div className="grid grid-cols-5 gap-1.5 sm:gap-2 max-w-sm">
                <div className="flex flex-col items-center">
                  <div className="w-full h-7 rounded-xs bg-[#E8C8C6] shadow-2xs border border-[#DEC0BE]"></div>
                  <span className="text-[9px] tracking-widest uppercase text-[#736E67] mt-1 text-center font-medium">Sakura</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-full h-7 rounded-xs bg-[#F6F3EE] shadow-2xs border border-[#E8E2D6]"></div>
                  <span className="text-[9px] tracking-widest uppercase text-[#736E67] mt-1 text-center font-medium">Pearl</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-full h-7 rounded-xs bg-[#E1DDD8] shadow-2xs border border-[#D5CFCA]"></div>
                  <span className="text-[9px] tracking-widest uppercase text-[#736E67] mt-1 text-center font-medium">Greige</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-full h-7 rounded-xs bg-[#869CA9] shadow-2xs border border-[#7A909D]"></div>
                  <span className="text-[9px] tracking-widest uppercase text-[#736E67] mt-1 text-center font-medium">Mist</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-full h-7 rounded-xs bg-[#282A2E] shadow-2xs border border-[#1E2024]"></div>
                  <span className="text-[9px] tracking-widest uppercase text-[#736E67] mt-1 text-center font-medium">Ink</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Asset Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Main Flacon Visual Container */}
              <div className="relative rounded-xs overflow-hidden bg-white p-4 sm:p-5 shadow-sm border border-[#E5DFD4]">
                <div className="relative aspect-4/5 sm:aspect-3/4 overflow-hidden rounded-xs bg-[#F3EFEA]">
                  <img
                    src="/src/assets/images/coordinates_parfum_bottle_1790683053639.jpg"
                    alt="co°rdinates bespoke perfume personalized bottle"
                    className="w-full h-full object-cover object-center transition-transform duration-700 hover:scale-103"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      // Fallback image if needed
                      (e.target as HTMLImageElement).src = '/src/assets/images/hero_bespoke_perfume_1790682969399.jpg';
                    }}
                  />
                  
                  {/* Subtle Stamp Overlay */}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-xs border border-[#D8CFBF] rounded-full p-2.5 text-center shadow-xs">
                    <span className="block text-[8px] tracking-[0.25em] uppercase text-[#6B655B] font-semibold">TOKYO</span>
                    <span className="block text-[11px] font-serif text-[#1F2124]">東京</span>
                    <span className="block text-[7px] tracking-[0.2em] uppercase text-[#708794]">PARFUM</span>
                  </div>

                  {/* Bottom Note Preview Overlay */}
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#1F2124]/80 via-[#1F2124]/40 to-transparent p-4 text-white">
                    <div className="text-[10px] tracking-[0.2em] uppercase text-[#E5C5C2] font-semibold">
                      co°rdinates signature
                    </div>
                    <div className="text-sm font-serif-title tracking-wide text-white">
                      Cherry Blossom · White Musk · Neroli
                    </div>
                    <div className="text-[10px] font-mono tabular-nums text-white/80 mt-0.5">
                      35° 41&apos; 1.4964&quot; N · 139° 46&apos; 2.2368&quot; E
                    </div>
                  </div>
                </div>

                {/* Sub-card: Face to face note */}
                <div className="mt-4 pt-3 border-t border-[#ECE7DD] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-[#5A554D]">
                    <MapPin className="w-3.5 h-3.5 text-[#708794]" />
                    <span>Face to Face Sessions in Metro Manila</span>
                  </div>
                  <span className="text-[11px] tracking-wider uppercase font-semibold text-[#8A7969]">First Class</span>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
