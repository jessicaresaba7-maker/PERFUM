import React, { useState } from 'react';
import { WEDDING_PACKAGES, STAG_BACHELORETTE_PACKAGE } from '../data/packagesData';
import { PackageTier } from '../types/perfume';
import { Check, Sparkles, MapPin, Box, Users, ArrowUpRight } from 'lucide-react';

interface PackagesSectionProps {
  onSelectPackageForQuote: (pkgId: string) => void;
  onBookSession: (pkgId?: string) => void;
}

export const PackagesSection: React.FC<PackagesSectionProps> = ({ 
  onSelectPackageForQuote, 
  onBookSession 
}) => {
  const [activeTab, setActiveTab] = useState<'wedding' | 'stag'>('wedding');

  return (
    <section id="packages" className="py-16 sm:py-24 bg-[#FAF8F5] border-b border-[#EAE4D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-[#E8E2D6] gap-4">
          <div>
            <div className="text-xs tracking-[0.25em] uppercase text-[#708794] font-medium mb-1.5 flex items-center gap-1.5">
              <span>Bespoke Event Collections</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-serif-title font-medium text-[#1F2124] tracking-tight">
              Curated Fragrance Packages
            </h2>
          </div>

          {/* Interactive Filter Tabs (Functional segmented buttons permitted by constitution) */}
          <div className="flex items-center p-1 bg-[#EFEAE1] rounded-xs border border-[#DFD8CC]">
            <button
              onClick={() => setActiveTab('wedding')}
              className={`px-4 py-2 text-xs tracking-[0.14em] uppercase font-semibold transition-all rounded-2xs cursor-pointer ${
                activeTab === 'wedding'
                  ? 'bg-white text-[#1F2124] shadow-xs'
                  : 'text-[#615C54] hover:text-[#1F2124]'
              }`}
            >
              Wedding / Debut / Baby Shower
            </button>
            <button
              onClick={() => setActiveTab('stag')}
              className={`px-4 py-2 text-xs tracking-[0.14em] uppercase font-semibold transition-all rounded-2xs cursor-pointer ${
                activeTab === 'stag'
                  ? 'bg-white text-[#1F2124] shadow-xs'
                  : 'text-[#615C54] hover:text-[#1F2124]'
              }`}
            >
              Stag / Bachelorette
            </button>
          </div>
        </div>

        {/* Tab 1: WEDDING / DEBUT / BABY SHOWER PACKAGE (First Class, Business Class, Regular Class) */}
        {activeTab === 'wedding' && (
          <div>
            {/* Visual spotlight bar */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12 items-center bg-[#F4EFE6] p-6 sm:p-8 rounded-xs border border-[#E3DBD0]">
              <div className="lg:col-span-4">
                <div className="aspect-4/3 rounded-xs overflow-hidden border border-[#DCD3C5] bg-white">
                  <img
                    src="/src/assets/images/atelier_perfume_session_1790682983178.jpg"
                    alt="Face to face perfume making session"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
              <div className="lg:col-span-8 space-y-3">
                <div className="text-[11px] tracking-[0.2em] uppercase text-[#708794] font-semibold flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#B89694]" />
                  <span>Exclusive Atelier Experience</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-serif-title font-medium text-[#1F2124]">
                  Face to Face Perfume Making Session & Custom Discovery Sets
                </h3>
                <p className="text-xs sm:text-sm text-[#5B564E] leading-relaxed font-light">
                  Whether you prefer an intimate 2-hour perfume blending masterclass in Metro Manila (First Class), 
                  or the convenience of unboxing 20 scents in the comfort of your home anywhere in the Philippines (Business Class), 
                  we ensure every flacon honors your love story and event coordinates.
                </p>
                <div className="pt-1 flex items-center gap-4 text-xs text-[#706B62]">
                  <span className="font-mono">Eau de Parfum Concentration</span>
                  <span aria-hidden="true">·</span>
                  <span>Personalized Caps & Cotton Labels</span>
                  <span aria-hidden="true">·</span>
                  <span>Direct Venue Coordination</span>
                </div>
              </div>
            </div>

            {/* The 3 Tiers Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-stretch">
              {WEDDING_PACKAGES.map((pkg, index) => {
                const isFirstClass = pkg.id === 'first-class';
                const isBusinessClass = pkg.id === 'business-class';

                return (
                  <div
                    key={pkg.id}
                    className={`relative flex flex-col justify-between p-6 sm:p-8 rounded-xs border transition-all duration-300 ${
                      isFirstClass
                        ? 'bg-[#FFFFFF] border-[#1F2124] shadow-md ring-1 ring-[#1F2124]'
                        : 'bg-[#FBF9F5] border-[#E2DBD0] hover:border-[#BFB7A8] shadow-2xs'
                    }`}
                  >
                    <div>
                      {/* Quiet Index + Badge */}
                      <div className="flex items-center justify-between text-xs mb-3 text-[#7A746B]">
                        <span className="font-mono tracking-widest uppercase">0{index + 1} TIER</span>
                        <span className="text-[11px] tracking-wider uppercase font-semibold text-[#8A7969]">
                          {pkg.badge}
                        </span>
                      </div>

                      {/* Title & Subtitle */}
                      <h3 className="text-xl sm:text-2xl font-serif-title font-semibold text-[#1F2124]">
                        {pkg.name}
                      </h3>
                      
                      <p className="text-xs text-[#6B655B] font-light mt-1.5 min-h-[32px]">
                        {pkg.subtitle}
                      </p>

                      {/* Pricing Benchmarks in Tabular numbers */}
                      <div className="mt-5 pb-5 border-b border-[#EAE3D6]">
                        <div className="flex items-baseline gap-1">
                          <span className="text-xs text-[#787268] font-mono">PHP</span>
                          <span className="text-3xl font-serif-title font-bold text-[#1F2124] tabular-nums">
                            ₱{pkg.basePrice.toLocaleString()}
                          </span>
                        </div>
                        <span className="text-[11px] text-[#868076] block mt-0.5">
                          Base atelier package + personalized flacons
                        </span>
                      </div>

                      {/* Scents Capacity Marker */}
                      <div className="py-3 text-xs flex items-center justify-between text-[#4D4943] bg-[#F5F1E8] px-3 rounded-2xs my-4 border border-[#E7E0D2]">
                        <span className="font-medium">Fragrance Variety:</span>
                        <span className="font-semibold text-[#1F2124]">
                          Maximum of {pkg.maxScents} Scents
                        </span>
                      </div>

                      {/* Itemized Feature Checklist */}
                      <div className="space-y-3 pt-1">
                        <span className="text-[11px] tracking-[0.16em] uppercase font-semibold text-[#4F4A42] block">
                          Included In This Tier:
                        </span>
                        
                        <ul className="space-y-2.5 text-xs text-[#524E46]">
                          {pkg.features.map((feat, i) => {
                            const isHighlight = feat.includes('Face to Face') || feat.includes('Discovery Set');
                            return (
                              <li key={i} className="flex items-start gap-2.5 leading-relaxed">
                                <Check className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${isHighlight ? 'text-[#1F2124] stroke-[2.5]' : 'text-[#708794]'}`} />
                                <span className={isHighlight ? 'font-medium text-[#1F2124]' : ''}>
                                  {feat}
                                </span>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    </div>

                    {/* Bottom Action Area */}
                    <div className="pt-8 mt-6 border-t border-[#EAE3D6] space-y-2">
                      <button
                        onClick={() => onSelectPackageForQuote(pkg.id)}
                        className={`w-full py-3 px-4 text-xs tracking-[0.16em] uppercase font-semibold rounded-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                          isFirstClass
                            ? 'bg-[#1F2124] text-white hover:bg-[#34373E]'
                            : 'bg-white text-[#1F2124] border border-[#D5CDC1] hover:border-[#1F2124]'
                        }`}
                      >
                        <span>Calculate Quote</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>

                      {isFirstClass && (
                        <button
                          onClick={() => onBookSession(pkg.id)}
                          className="w-full py-2 text-center text-[11px] tracking-wider uppercase text-[#736A5E] hover:text-[#1F2124] underline underline-offset-4 cursor-pointer"
                        >
                          Book Metro Manila Session
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: STAG / BACHELORETTE PACKAGE */}
        {activeTab === 'stag' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Description Card */}
            <div className="lg:col-span-7 bg-white p-6 sm:p-10 rounded-xs border border-[#E3DBD0] shadow-sm space-y-6">
              
              <div className="flex items-center justify-between text-xs text-[#708794] border-b border-[#EFE9DF] pb-4">
                <span className="font-mono tracking-widest uppercase">STAG & BACHELORETTE EDITION</span>
                <span className="tracking-wider uppercase font-semibold text-[#8A7969]">Bridesmaids & Groomsmen</span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-serif-title font-semibold text-[#1F2124]">
                  {STAG_BACHELORETTE_PACKAGE.name}
                </h3>
                <p className="text-xs sm:text-sm text-[#5B564E] font-light mt-2 leading-relaxed">
                  Celebrate the final days before the altar with signature scent memories. 
                  Crafted with dual scent portfolios designed specifically for the bridal tribe and groom crew.
                </p>
              </div>

              {/* Price */}
              <div className="bg-[#FAF8F4] p-4 rounded-xs border border-[#EAE3D6] flex items-baseline justify-between">
                <div>
                  <span className="text-xs text-[#787268] font-mono block">Package Investment</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-xs text-[#787268] font-mono">PHP</span>
                    <span className="text-2xl sm:text-3xl font-serif-title font-bold text-[#1F2124] tabular-nums">
                      ₱{STAG_BACHELORETTE_PACKAGE.basePrice.toLocaleString()}
                    </span>
                  </div>
                </div>
                <span className="text-xs text-[#7A746B]">
                  Includes custom bottle design & dual scent formulation
                </span>
              </div>

              {/* Features List */}
              <div className="space-y-3 pt-2">
                <span className="text-xs tracking-[0.16em] uppercase font-semibold text-[#3D3A35] block">
                  Package Specifications:
                </span>
                <ul className="space-y-3 text-xs text-[#4F4A42]">
                  {STAG_BACHELORETTE_PACKAGE.features.map((feat, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 mt-0.5 text-[#1F2124] shrink-0" />
                      <span className="leading-relaxed">{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 flex flex-wrap gap-3">
                <button
                  onClick={() => onSelectPackageForQuote(STAG_BACHELORETTE_PACKAGE.id)}
                  className="px-6 py-3 bg-[#1F2124] text-white text-xs tracking-[0.16em] uppercase font-semibold rounded-xs hover:bg-[#32363D] transition-colors cursor-pointer shadow-xs"
                >
                  Configure Stag / Bachelorette Quote
                </button>
                <button
                  onClick={() => onBookSession(STAG_BACHELORETTE_PACKAGE.id)}
                  className="px-5 py-3 bg-white text-[#1F2124] border border-[#D5CDC1] hover:border-[#1F2124] text-xs tracking-[0.16em] uppercase font-semibold rounded-xs transition-colors cursor-pointer"
                >
                  Inquire Schedule
                </button>
              </div>

            </div>

            {/* Right Visual & Scent Breakdown Card */}
            <div className="lg:col-span-5 space-y-4">
              
              {/* Bridesmaids Fragrance Box */}
              <div className="bg-[#FAF4F3] p-5 rounded-xs border border-[#E9D6D4]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-serif-title font-semibold tracking-wider text-[#A36662] uppercase">
                    Bridesmaids Fragrance Profile
                  </span>
                  <span className="text-[10px] font-mono uppercase bg-white/80 px-2 py-0.5 rounded-2xs text-[#7D4946]">
                    Max 2 Scents
                  </span>
                </div>
                <p className="text-xs text-[#6B5554] font-light leading-relaxed">
                  Luminous white blossoms, cherry petal mist, French neroli, and powdery clean white musks.
                </p>
                <div className="mt-3 pt-2 border-t border-[#E8CECC] text-[11px] text-[#7A5B5A] flex items-center justify-between">
                  <span>Bottle Cap: Pearl White or Sakura</span>
                  <span className="font-mono">50ml Eau de Parfum</span>
                </div>
              </div>

              {/* Groomsmen Fragrance Box */}
              <div className="bg-[#F0F3F5] p-5 rounded-xs border border-[#D2DDE3]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-serif-title font-semibold tracking-wider text-[#526D7C] uppercase">
                    Groomsmen Fragrance Profile
                  </span>
                  <span className="text-[10px] font-mono uppercase bg-white/80 px-2 py-0.5 rounded-2xs text-[#3E5867]">
                    Max 2 Scents
                  </span>
                </div>
                <p className="text-xs text-[#52636E] font-light leading-relaxed">
                  Japanese hinoki wood, smoked cedar, sea salt amber, and crisp bergamot citrus rind.
                </p>
                <div className="mt-3 pt-2 border-t border-[#CAD8E0] text-[11px] text-[#4C606C] flex items-center justify-between">
                  <span>Bottle Cap: Matte Obsidian Black</span>
                  <span className="font-mono">50ml Eau de Parfum</span>
                </div>
              </div>

              {/* Scent Discovery Image */}
              <div className="aspect-16/9 rounded-xs overflow-hidden border border-[#DDD5C7] bg-white">
                <img
                  src="/src/assets/images/fragrance_discovery_set_1790683005424.jpg"
                  alt="Discovery set fragrance vials"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

            </div>

          </div>
        )}

      </div>
    </section>
  );
};
