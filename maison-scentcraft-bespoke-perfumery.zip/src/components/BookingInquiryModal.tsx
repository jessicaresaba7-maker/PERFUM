import React, { useState } from 'react';
import { X, Check, Send, Phone, Calendar, MapPin, Sparkles, MessageCircle } from 'lucide-react';

interface BookingInquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefilledQuote?: string;
  initialPackageId?: string;
}

export const BookingInquiryModal: React.FC<BookingInquiryModalProps> = ({
  isOpen,
  onClose,
  prefilledQuote,
  initialPackageId
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [eventType, setEventType] = useState('Wedding');
  const [eventDate, setEventDate] = useState('');
  const [eventLocation, setEventLocation] = useState('Metro Manila');
  const [estimatedPax, setEstimatedPax] = useState('30-50 pax');
  const [specialRequests, setSpecialRequests] = useState(prefilledQuote || '');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [inquiryCode, setInquiryCode] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedCode = 'CP-' + Math.floor(100000 + Math.random() * 900000);
    setInquiryCode(generatedCode);
    setIsSubmitted(true);
  };

  const handleOpenViberWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello Atelier Co°rdinates Parfum! I would like to inquire about booking/consultation.\n\nInquiry Ref: ${inquiryCode}\nName: ${fullName}\nEvent: ${eventType}\nDate: ${eventDate}\nVenue: ${eventLocation}\nEstimated Pax: ${estimatedPax}\n\nDetails:\n${specialRequests}`
    );
    window.open(`https://wa.me/639178881234?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#FAF8F5] rounded-xs border border-[#DFD8CC] shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-[#E8E2D6]">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-semibold text-[#1F2124]">
            <Sparkles className="w-4 h-4 text-[#B89694]" />
            <span>Consultation & Atelier Reservation</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6B655B] hover:text-[#1F2124] transition-colors rounded-xs cursor-pointer"
            aria-label="Close inquiry modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="p-8 sm:p-12 text-center space-y-6">
            <div className="w-14 h-14 bg-[#F2EAE0] text-[#1F2124] border border-[#DECDBB] rounded-full mx-auto flex items-center justify-center shadow-xs">
              <Check className="w-7 h-7 text-[#8A7969]" />
            </div>

            <div>
              <span className="text-xs font-mono text-[#7D776E] tracking-widest uppercase block">
                Reservation Reference
              </span>
              <div className="text-2xl sm:text-3xl font-serif-title font-bold text-[#1F2124] mt-1">
                {inquiryCode}
              </div>
              <h3 className="text-lg font-serif-title text-[#1F2124] mt-2">
                Thank You, {fullName}! Your Fragrance Inquiry is Confirmed.
              </h3>
              <p className="text-xs sm:text-sm text-[#5B554D] font-light max-w-md mx-auto mt-2 leading-relaxed">
                Our head perfumer will review your event date ({eventDate || 'TBD'}) and custom specifications. 
                We will reach out via Viber / WhatsApp or Email within 24 hours.
              </p>
            </div>

            <div className="p-4 bg-white rounded-xs border border-[#E3DBD0] text-xs text-left max-w-md mx-auto space-y-1.5">
              <div className="flex justify-between text-[#6B655D]">
                <span>Event Occasion:</span>
                <span className="font-semibold text-[#1F2124]">{eventType}</span>
              </div>
              <div className="flex justify-between text-[#6B655D]">
                <span>Venue Area:</span>
                <span className="font-semibold text-[#1F2124]">{eventLocation}</span>
              </div>
              <div className="flex justify-between text-[#6B655D]">
                <span>Contact Number:</span>
                <span className="font-mono text-[#1F2124]">{phone}</span>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={handleOpenViberWhatsApp}
                className="w-full sm:w-auto px-5 py-2.5 bg-[#1F2124] text-white text-xs tracking-[0.16em] uppercase font-semibold rounded-xs hover:bg-[#34373F] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <MessageCircle className="w-4 h-4 text-[#869CA9]" />
                <span>Chat via WhatsApp / Viber</span>
              </button>
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 bg-white text-[#1F2124] border border-[#D5CDC1] hover:border-[#1F2124] text-xs tracking-[0.16em] uppercase font-semibold rounded-xs transition-colors cursor-pointer"
              >
                Back to Studio
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-5 max-h-[75vh] overflow-y-auto">
            
            <p className="text-xs text-[#5C574F] font-light leading-relaxed">
              Fill in your celebration details below to check atelier slot availability for 
              Face-to-Face sessions in Metro Manila, or to arrange discovery set delivery nationwide.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                  Full Name / Couple Names *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Maria Santos & Carlos Reyes"
                  className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
                />
              </div>

              <div>
                <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                  Mobile / Viber / WhatsApp Number *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 0917-123-4567"
                  className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. client@gmail.com"
                  className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
                />
              </div>

              <div>
                <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                  Event Occasion *
                </label>
                <select
                  value={eventType}
                  onChange={(e) => setEventType(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
                >
                  <option value="Wedding">Wedding</option>
                  <option value="18th Debut">18th Debut</option>
                  <option value="Baby Shower / Baptism">Baby Shower / Baptism</option>
                  <option value="Stag / Bachelorette">Stag / Bachelorette</option>
                  <option value="Special Corporate Event">Special Corporate Event</option>
                  <option value="Milestone Birthday">Milestone Birthday / Gala</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                  Target Event Date
                </label>
                <input
                  type="date"
                  value={eventDate}
                  onChange={(e) => setEventDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
                />
              </div>

              <div>
                <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                  Venue / Location *
                </label>
                <select
                  value={eventLocation}
                  onChange={(e) => setEventLocation(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
                >
                  <option value="Metro Manila">Metro Manila (Eligible for Face to Face Session)</option>
                  <option value="Tagaytay / Cavite">Tagaytay / Cavite Area</option>
                  <option value="Laguna / Batangas">Laguna / Batangas</option>
                  <option value="Pampanga / Clark">Pampanga / Clark</option>
                  <option value="Boracay / Palawan / Destination">Destination Wedding / Provincial (Air Cargo Delivery)</option>
                  <option value="Cebu / Davao / VisMin">Cebu / Davao / VisMin</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                Estimated Bottle Count / Pax Tier
              </label>
              <select
                value={estimatedPax}
                onChange={(e) => setEstimatedPax(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124]"
              >
                <option value="15-30 pax">15 – 30 pax</option>
                <option value="31-50 pax">31 – 50 pax</option>
                <option value="51-80 pax">51 – 80 pax</option>
                <option value="81-100 pax">81 – 100 pax</option>
                <option value="100+ pax">100+ pax & above (Corporate / Large Gathering)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] tracking-[0.16em] uppercase font-semibold text-[#3C3933] mb-1">
                Package Choice, Coordinates & Custom Details
              </label>
              <textarea
                rows={4}
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
                placeholder="Include your preferred package (First Class, Business Class, Regular Class, Stag/Bachelorette), preferred scent notes, church/reception coordinates, or any custom requests..."
                className="w-full px-3 py-2 text-xs bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124] font-mono leading-relaxed"
              />
            </div>

            <div className="pt-2 border-t border-[#E8E2D6] flex items-center justify-between gap-3">
              <span className="text-[11px] text-[#7A746B]">
                *Face to face sessions strictly for Metro Manila clients (max 2 hrs).
              </span>
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#1F2124] text-white text-xs tracking-[0.16em] uppercase font-semibold rounded-xs hover:bg-[#34373F] transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Send className="w-3.5 h-3.5 text-[#E5C5C2]" />
                <span>Submit Inquiry</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
