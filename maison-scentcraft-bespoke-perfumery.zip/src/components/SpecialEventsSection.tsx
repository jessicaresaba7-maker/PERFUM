import React, { useState } from 'react';
import { SPECIAL_EVENTS_PACKAGES } from '../data/packagesData';
import { Users, Check, Sparkles, Building2, Cake, GlassWater, ArrowRight } from 'lucide-react';

interface SpecialEventsSectionProps {
  onSelectEventsTier: (tierId: string) => void;
  onOpenConsultation: () => void;
}

export const SpecialEventsSection: React.FC<SpecialEventsSectionProps> = ({
  onSelectEventsTier,
  onOpenConsultation
}) => {
  const [selectedTierId, setSelectedTierId] = useState<string>('events-31-50');

  const currentTier = SPECIAL_EVENTS_PACKAGES.find(p => p.id === selectedTierId) || SPECIAL_EVENTS_PACKAGES[1];

  return (
    <section id="special-events" className="py-16 sm:py-24 bg-[#FAF8F5] border-b border-[#EAE4D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs tracking-[0.25em] uppercase text-[#708794] font-medium mb-1.5 flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-[#B89694]" />
            <span>Corporate Events · Birthdays · Grand Galas</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-serif-title font-medium text-[#1F2124] tracking-tight">
            Special Events Package (By Pax Tier)
          </h2>
          <p className="text-xs sm:text-sm text-[#5C574F] mt-2 font-light">
            Scalable bespoke perfume production and live fragrance bar experiences tailored for 
            15 to 100+ guests. Perfect for brand activations, milestone birthdays, corporate holiday banquets, and grand society events.
          </p>
        </div>

        {/* Pax Tier Selector Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-8">
          {SPECIAL_EVENTS_PACKAGES.map((pkg) => {
            const isSelected = pkg.id === selectedTierId;
            return (
              <button
                key={pkg.id}
                onClick={() => setSelectedTierId(pkg.id)}
                className={`py-3 px-3 text-center rounded-xs border transition-all cursor-pointer flex flex-col items-center justify-center ${
                  isSelected
                    ? 'bg-[#1F2124] text-white border-[#1F2124] shadow-sm'
                    : 'bg-white text-[#4A463E] border-[#DCD5C9] hover:border-[#AFA698]'
                }`}
              >
                <span className="text-xs sm:text-sm font-semibold tracking-wider">
                  {pkg.name}
                </span>
                <span className={`text-[10px] uppercase tracking-wider mt-0.5 ${
                  isSelected ? 'text-[#E5C5C2]' : 'text-[#847E74]'
                }`}>
                  {pkg.id === 'events-100-plus' ? 'Large Gatherings' : 'Tailored Pax'}
                </span>
              </button>
            );
          })}
        </div>

        {/* Active Tier Spotlight Card */}
        <div className="bg-white rounded-xs border border-[#DFD8CC] shadow-sm p-6 sm:p-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
            
            {/* Left Column: Details & Inclusions */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="flex items-center justify-between border-b border-[#EFEBE4] pb-4">
                <div className="flex items-center gap-2 text-xs text-[#708794]">
                  <Users className="w-4 h-4 text-[#B89694]" />
                  <span className="font-mono tracking-widest uppercase">{currentTier.name} Tier Details</span>
                </div>
                <span className="text-[11px] tracking-wider uppercase font-semibold text-[#8A7969]">
                  Max {currentTier.maxScents} Curated Scents
                </span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-serif-title font-semibold text-[#1F2124]">
                  {currentTier.subtitle}
                </h3>
                <p className="text-xs sm:text-sm text-[#5B564E] font-light mt-2 leading-relaxed">
                  {currentTier.description}
                </p>
              </div>

              {/* Price estimation */}
              <div className="p-4 bg-[#FAF8F5] rounded-xs border border-[#EAE3D6] flex flex-wrap items-baseline justify-between gap-2">
                <div>
                  <span className="text-[11px] text-[#7A746B] font-mono uppercase block">Estimated Tier Investment</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-xs text-[#787268] font-mono">PHP</span>
                    <span className="text-2xl sm:text-3xl font-serif-title font-bold text-[#1F2124] tabular-nums">
                      ₱{currentTier.basePrice.toLocaleString()}
                    </span>
                    <span className="text-xs text-[#787268] ml-1">
                      {currentTier.id === 'events-100-plus' ? '(starts at 100 bottles)' : `(for ${currentTier.minPax}–${currentTier.maxPax} bottles)`}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-[#869CA9] uppercase font-mono tracking-wider block">Production Time</span>
                  <span className="text-xs font-medium text-[#4B4740]">7 to 14 Business Days</span>
                </div>
              </div>

              {/* Features list */}
              <div className="space-y-3 pt-1">
                <span className="text-xs tracking-[0.16em] uppercase font-semibold text-[#3C3833] block">
                  Included In {currentTier.name}:
                </span>
                <ul className="space-y-2.5 text-xs text-[#524E46]">
                  {currentTier.features.map((feat, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <Check className="w-3.5 h-3.5 mt-0.5 text-[#1F2124] shrink-0" />
                      <span className="leading-relaxed">{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* CTA buttons */}
              <div className="pt-4 flex flex-wrap gap-3">
                <button
                  onClick={() => onSelectEventsTier(currentTier.id)}
                  className="px-6 py-3 bg-[#1F2124] text-white text-xs tracking-[0.16em] uppercase font-semibold rounded-xs hover:bg-[#34373F] transition-colors cursor-pointer flex items-center gap-2 shadow-xs"
                >
                  <span>Select {currentTier.name} For Quote</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={onOpenConsultation}
                  className="px-5 py-3 bg-white text-[#1F2124] border border-[#D5CDC1] hover:border-[#1F2124] text-xs tracking-[0.16em] uppercase font-semibold rounded-xs transition-colors cursor-pointer"
                >
                  Request Corporate Consultation
                </button>
              </div>

            </div>

            {/* Right Column: Event Types & Live Bar Experience */}
            <div className="lg:col-span-5 space-y-4">
              
              {/* Event Occasion Types */}
              <div className="p-5 bg-[#FAF7F2] rounded-xs border border-[#E5DFD4] space-y-3">
                <span className="text-xs font-serif-title font-semibold tracking-wider text-[#1F2124] uppercase block">
                  Recommended For These Gatherings:
                </span>
                
                <div className="space-y-2.5 text-xs text-[#5A554D]">
                  <div className="flex items-start gap-2.5">
                    <Building2 className="w-4 h-4 text-[#708794] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-[#1F2124]">Corporate Events & Brand Activations:</span>
                      <p className="font-light text-[11px] text-[#696359] mt-0.5">
                        Brand logo hot-stamping, custom company coordinates, and executive client appreciation favors.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <Cake className="w-4 h-4 text-[#B89694] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-[#1F2124]">Milestone Birthdays & 18th Debuts:</span>
                      <p className="font-light text-[11px] text-[#696359] mt-0.5">
                        18 Roses / 18 Treasures custom keepsakes with debutante's signature chosen note.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <GlassWater className="w-4 h-4 text-[#8A7969] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-[#1F2124]">Live Fragrance Bar Experience (100+ Pax):</span>
                      <p className="font-light text-[11px] text-[#696359] mt-0.5">
                        On-site mobile perfume bar with uniformed scent baristas who bottle personalized fragrances live for your guests!
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Delivery info */}
              <div className="p-4 bg-[#F2F6F8] rounded-xs border border-[#CFDFE7] text-xs text-[#4F6877]">
                <span className="font-semibold block text-[#365160] mb-1">
                  Logistics & Metro Manila Venue Direct Drop:
                </span>
                <p className="text-[11px] leading-relaxed">
                  We coordinate directly with your wedding coordinator, hotel concierge, or event organizer to ensure all bottled favors arrive 
                  safety-checked and sequenced by table or seating plan.
                </p>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
