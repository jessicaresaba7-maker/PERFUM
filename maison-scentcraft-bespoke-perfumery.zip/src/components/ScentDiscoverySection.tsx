import React, { useState } from 'react';
import { SCENT_LIBRARY } from '../data/packagesData';
import { Sparkles, Droplets, Compass } from 'lucide-react';

export const ScentDiscoverySection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Floral', 'Woody', 'Citrus & Fresh', 'Gourmand & Warm', 'Aquatic', 'Oriental & Amber'];

  const filteredScents = selectedCategory === 'All' 
    ? SCENT_LIBRARY 
    : SCENT_LIBRARY.filter(s => s.category === selectedCategory);

  return (
    <section id="discovery" className="py-16 sm:py-24 bg-[#F7F4EE] border-b border-[#E8E2D6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-[#E3DBD0] gap-4">
          <div>
            <div className="text-xs tracking-[0.25em] uppercase text-[#708794] font-medium mb-1.5 flex items-center gap-1.5">
              <Droplets className="w-3.5 h-3.5 text-[#B89694]" />
              <span>Haute Parfumerie Formulations</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-serif-title font-medium text-[#1F2124] tracking-tight">
              Artisanal Scent Library
            </h2>
            <p className="text-xs sm:text-sm text-[#5C574F] mt-1.5 font-light max-w-xl">
              From our 10-scent and 20-scent Discovery Sets included in our Regular and Business Class packages, 
              explore our signature olfactory accords formulated with 28% Eau de Parfum oil concentration.
            </p>
          </div>

          {/* Category Tabs (Functional buttons) */}
          <div className="flex flex-wrap gap-1 p-1 bg-[#EBE5DB] rounded-xs border border-[#DBD2C4]">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-[11px] tracking-wider uppercase font-medium rounded-2xs transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-white text-[#1F2124] shadow-xs'
                    : 'text-[#615C54] hover:text-[#1F2124]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Discovery Set Spotlight Banner */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-12 items-center bg-white p-6 sm:p-8 rounded-xs border border-[#E0D8CB]">
          <div className="lg:col-span-4">
            <div className="aspect-4/3 rounded-xs overflow-hidden border border-[#D5CDC0] bg-[#FAF8F5]">
              <img
                src="/src/assets/images/fragrance_discovery_set_1790683005424.jpg"
                alt="Discovery Set box containing fragrance vials"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="lg:col-span-8 space-y-3">
            <div className="text-[11px] tracking-[0.2em] uppercase text-[#708794] font-semibold flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-[#B89694]" />
              <span>Doorstep Olfactory Journey</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-serif-title font-medium text-[#1F2124]">
              How the Discovery Set Works
            </h3>
            <p className="text-xs sm:text-sm text-[#5B564E] leading-relaxed font-light">
              Clients who select our <strong className="font-semibold text-[#1F2124]">Business Class (20 Scents)</strong> or <strong className="font-semibold text-[#1F2124]">Regular Class (10 Scents)</strong> package receive a curated discovery box at home. 
              Wear each accord throughout the day, note how it evolves with your skin chemistry, and pick your top 2 or 3 favorite scents to be bottled for your celebration.
            </p>
            <div className="pt-1 flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-[#706B62]">
              <span className="font-mono">Includes Testing Blotters</span>
              <span aria-hidden="true">·</span>
              <span>Skin Wear Guide</span>
              <span aria-hidden="true">·</span>
              <span>Complimentary Digital Selection Form</span>
            </div>
          </div>
        </div>

        {/* Scent Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredScents.map((scent) => (
            <div
              key={scent.id}
              className="bg-white p-5 rounded-xs border border-[#E2DBD0] hover:border-[#BFB7A8] transition-all duration-200 shadow-2xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-[#7D776E] border-b border-[#EFEBE4] pb-2.5 mb-3">
                  <span className="text-[10px] tracking-widest uppercase font-mono">{scent.category}</span>
                  <span className="text-[10px] tracking-wider uppercase font-semibold text-[#8A7969]">Eau de Parfum</span>
                </div>

                <h4 className="text-lg font-serif-title font-semibold text-[#1F2124]">
                  {scent.name}
                </h4>

                <p className="text-xs text-[#635E56] font-light mt-1.5 leading-relaxed min-h-[44px]">
                  {scent.description}
                </p>

                {/* Fragrance pyramid breakdown */}
                <div className="mt-4 pt-3 border-t border-[#EFEBE4] space-y-2 text-[11px]">
                  <div>
                    <span className="text-[#878074] uppercase text-[9px] tracking-widest block font-medium">Top Notes</span>
                    <span className="text-[#3D3A34] font-medium">{scent.topNotes.join(', ')}</span>
                  </div>
                  <div>
                    <span className="text-[#878074] uppercase text-[9px] tracking-widest block font-medium">Heart Notes</span>
                    <span className="text-[#3D3A34] font-medium">{scent.heartNotes.join(', ')}</span>
                  </div>
                  <div>
                    <span className="text-[#878074] uppercase text-[9px] tracking-widest block font-medium">Base Notes</span>
                    <span className="text-[#3D3A34] font-medium">{scent.baseNotes.join(', ')}</span>
                  </div>
                </div>
              </div>

              {/* Vibe badge */}
              <div className="mt-4 pt-3 border-t border-[#F0ECE3] text-[11px] text-[#7A7367] italic">
                &ldquo;{scent.vibe}&rdquo;
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
