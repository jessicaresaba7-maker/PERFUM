import React from 'react';
import { Compass, Sparkles, Droplets, Truck } from 'lucide-react';

export const ProcessTimeline: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Consultation & Scent Discovery',
      description: 'Book your 2-hour Face to Face Perfume Making Session in Metro Manila (First Class) or unbox your 10 to 20 scent discovery set delivered to your doorstep.',
      icon: Droplets
    },
    {
      num: '02',
      title: 'Coordinates & Label Artistry',
      description: 'We draft personalized label proofs featuring your official ceremony coordinates, event date, custom motif colorway, and selected notes.',
      icon: Compass
    },
    {
      num: '03',
      title: 'Haute Parfumerie Bottling',
      description: 'Hand-blended with high-grade fragrance oils at 28% concentration for long-lasting sillage. Fitted with fine mist pumps and your chosen cap finish.',
      icon: Sparkles
    },
    {
      num: '04',
      title: 'Direct Event Dispatch',
      description: 'Carefully packaged with individual gift boxes, custom wax seals, and safely delivered directly to your Metro Manila venue coordinator or nationwide.',
      icon: Truck
    }
  ];

  return (
    <section className="py-16 sm:py-20 bg-[#FAF8F5] border-b border-[#E8E2D6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="text-xs tracking-[0.25em] uppercase text-[#708794] font-medium mb-1.5">
            The Bespoke Atelier Journey
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif-title font-medium text-[#1F2124]">
            How We Bottle Your Milestone
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div key={step.num} className="relative space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xs bg-white border border-[#DDD5C7] flex items-center justify-center text-[#1F2124] shadow-2xs">
                    <Icon className="w-4 h-4 text-[#8A7969]" />
                  </div>
                  <span className="font-mono text-sm tracking-wider text-[#8A847C] font-semibold">
                    {step.num}
                  </span>
                </div>

                <h3 className="text-base font-serif-title font-semibold text-[#1F2124] tracking-wide">
                  {step.title}
                </h3>

                <p className="text-xs text-[#5E5951] font-light leading-relaxed">
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
