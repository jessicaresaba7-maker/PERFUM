import React from 'react';
import { Compass, MapPin, Mail, Phone, Instagram } from 'lucide-react';

interface FooterProps {
  onOpenQuote: () => void;
  onOpenInquiry: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenQuote, onOpenInquiry }) => {
  return (
    <footer className="bg-[#1F2124] text-[#C9C3B8] pt-14 pb-10 border-t border-[#31343A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#363940]">
          
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="text-xl font-serif-title tracking-[0.22em] text-[#FAF6EE] uppercase font-semibold">
              co°rdinates <span className="text-xs font-sans-body tracking-[0.3em] font-normal lowercase text-[#869CA9]">parfum</span>
            </div>
            
            <p className="text-xs text-[#9E978C] font-light leading-relaxed max-w-sm">
              Artisanal bespoke perfume bar & personalized fragrance favors for Weddings, Debuts, 
              Baby Showers, Stag & Bachelorettes, and Special Events. Hand-crafted in Metro Manila, Philippines.
            </p>

            <div className="space-y-1.5 text-xs text-[#B5AEA3]">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#E5C5C2]" />
                <span>Atelier Studio: Bonifacio Global City & Makati, Metro Manila</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#869CA9]" />
                <span>concierge@coordinatesparfum.ph</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-[11px] tracking-[0.2em] uppercase font-semibold text-[#FAF6EE] block">
              Event Packages
            </span>
            <ul className="space-y-2 text-xs text-[#A8A196]">
              <li><a href="#packages" className="hover:text-white transition-colors">First Class (Face to Face Session)</a></li>
              <li><a href="#packages" className="hover:text-white transition-colors">Business Class (20 Scents Set)</a></li>
              <li><a href="#packages" className="hover:text-white transition-colors">Regular Class (10 Scents Set)</a></li>
              <li><a href="#packages" className="hover:text-white transition-colors">Stag & Bachelorette Package</a></li>
              <li><a href="#special-events" className="hover:text-white transition-colors">Special Events (15 to 100+ Pax)</a></li>
            </ul>
          </div>

          {/* Add-ons & Studio */}
          <div className="md:col-span-4 space-y-3">
            <span className="text-[11px] tracking-[0.2em] uppercase font-semibold text-[#FAF6EE] block">
              Bespoke Services
            </span>
            <ul className="space-y-2 text-xs text-[#A8A196]">
              <li><a href="#addons" className="hover:text-white transition-colors">Bride & Groom Perfume (2 × 100ml)</a></li>
              <li><a href="#addons" className="hover:text-white transition-colors">Entourage Gift Sets (Bridesmaids & Groomsmen)</a></li>
              <li><a href="#bottle-studio" className="hover:text-white transition-colors">Custom Coordinates Label Studio</a></li>
              <li><a href="#discovery" className="hover:text-white transition-colors">Discovery Set Scent Library</a></li>
            </ul>

            <div className="pt-2 flex gap-2">
              <button
                onClick={onOpenQuote}
                className="px-3.5 py-1.5 bg-[#2B2E33] hover:bg-[#383C42] border border-[#3E4249] text-xs text-[#FAF6EE] rounded-xs cursor-pointer transition-colors"
              >
                Instant Pricing ₱
              </button>
              <button
                onClick={onOpenInquiry}
                className="px-3.5 py-1.5 bg-[#FAF6EE] text-[#1F2124] text-xs font-semibold rounded-xs hover:bg-[#EBE5DB] cursor-pointer transition-colors"
              >
                Book Consultation
              </button>
            </div>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#787268] gap-3">
          <div>
            © {new Date().getFullYear()} co°rdinates parfum Atelier. All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-[#8C8477]">
            <span>Metro Manila Sessions (Max 2 Hours)</span>
            <span aria-hidden="true">·</span>
            <span>Nationwide Discovery Kits</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
