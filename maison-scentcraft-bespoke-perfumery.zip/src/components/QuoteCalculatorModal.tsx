import React, { useState, useEffect } from 'react';
import { 
  WEDDING_PACKAGES, 
  STAG_BACHELORETTE_PACKAGE, 
  SPECIAL_EVENTS_PACKAGES, 
  ADD_ON_ITEMS 
} from '../data/packagesData';
import { X, Check, Copy, Share2, Sparkles, Calculator, FileText } from 'lucide-react';

interface QuoteCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPackageId?: string;
  customDesignConfig?: {
    title: string;
    city: string;
    coords: string;
    palette: string;
    scents: string[];
  } | null;
  onProceedToInquiry: (quoteDetails: string) => void;
}

export const QuoteCalculatorModal: React.FC<QuoteCalculatorModalProps> = ({
  isOpen,
  onClose,
  initialPackageId = 'first-class',
  customDesignConfig,
  onProceedToInquiry
}) => {
  const [selectedPkgId, setSelectedPkgId] = useState<string>(initialPackageId);
  const [bottleCount, setBottleCount] = useState<number>(30);
  const [includeBrideGroomDuo, setIncludeBrideGroomDuo] = useState<boolean>(true);
  const [entourageQty, setEntourageQty] = useState<number>(8);
  const [includeWaxSealRibbon, setIncludeWaxSealRibbon] = useState<boolean>(true);
  const [copiedToast, setCopiedToast] = useState<boolean>(false);

  useEffect(() => {
    if (initialPackageId) {
      setSelectedPkgId(initialPackageId);
      if (initialPackageId === 'events-15-30') setBottleCount(25);
      else if (initialPackageId === 'events-31-50') setBottleCount(40);
      else if (initialPackageId === 'events-51-80') setBottleCount(65);
      else if (initialPackageId === 'events-81-100') setBottleCount(90);
      else if (initialPackageId === 'events-100-plus') setBottleCount(120);
      else setBottleCount(30);
    }
  }, [initialPackageId]);

  if (!isOpen) return null;

  // Find selected package across lists
  const allPackages = [
    ...WEDDING_PACKAGES,
    STAG_BACHELORETTE_PACKAGE,
    ...SPECIAL_EVENTS_PACKAGES
  ];

  const currentPkg = allPackages.find(p => p.id === selectedPkgId) || WEDDING_PACKAGES[0];

  // Price calculations
  let basePackageTotal = currentPkg.basePrice;
  let brideGroomTotal = includeBrideGroomDuo ? 4500 : 0;
  let entourageTotal = entourageQty > 0 ? entourageQty * 680 : 0;
  let waxSealTotal = includeWaxSealRibbon ? 1500 : 0;

  const grandTotal = basePackageTotal + brideGroomTotal + entourageTotal + waxSealTotal;

  // Format Quote Text for Copying / Sharing
  const generateQuoteText = () => {
    return `✦ MAISON CO°RDINATES PARFUM — OFFICIAL ESTIMATE ✦
Date: ${new Date().toLocaleDateString('en-PH', { year: 'numeric', month: 'long', day: 'numeric' })}

SELECTED PACKAGE:
• ${currentPkg.name} (${currentPkg.subtitle})
  Base Investment: ₱${basePackageTotal.toLocaleString()}
  Max Scents: ${currentPkg.maxScents}
  ${currentPkg.includesFaceToFace ? '✓ Includes: Face-to-Face Perfume Making Session (Metro Manila; max 2 hrs)' : ''}
  ${currentPkg.discoverySetCount ? `✓ Includes: ${currentPkg.discoverySetCount} Scent Discovery Box` : ''}

ADD-ONS:
${includeBrideGroomDuo ? '• Bride & Groom Duo (2 × 100ml statement bottles + luxury box): ₱4,500' : '• Bride & Groom Duo: None'}
${entourageQty > 0 ? `• Entourage Gift Sets: ${entourageQty} bottles @ ₱680 = ₱${entourageTotal.toLocaleString()} (Max 2 scents for Bridesmaids & 2 scents for Groomsmen)` : '• Entourage Gifts: None'}
${includeWaxSealRibbon ? '• Custom Wax Seal Stamping & Hand-Tied Satin Ribbon: ₱1,500' : ''}

${customDesignConfig ? `CUSTOM DESIGN SPECS:
• Label Title: ${customDesignConfig.title}
• Location / Venue: ${customDesignConfig.city}
• Coordinates: ${customDesignConfig.coords}
• Palette: ${customDesignConfig.palette}
• Selected Scents: ${customDesignConfig.scents.join(', ')}
` : ''}
------------------------------------------
TOTAL ESTIMATE: ₱${grandTotal.toLocaleString()}
Terms: 50% reservation downpayment, 50% upon final batch dispatch.
Atelier Location: Metro Manila, Philippines`;
  };

  const handleCopyQuote = () => {
    navigator.clipboard.writeText(generateQuoteText());
    setCopiedToast(true);
    setTimeout(() => setCopiedToast(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#FAF8F5] rounded-xs border border-[#DFD8CC] shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-[#E8E2D6]">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-semibold text-[#1F2124]">
            <Calculator className="w-4 h-4 text-[#708794]" />
            <span>Instant Package & Add-On Calculator</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6B655B] hover:text-[#1F2124] transition-colors rounded-xs cursor-pointer"
            aria-label="Close quote modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Step 1: Select Main Package */}
          <div>
            <label className="block text-xs tracking-[0.16em] uppercase font-semibold text-[#3D3A34] mb-2">
              01. Choose Your Base Package
            </label>
            <select
              value={selectedPkgId}
              onChange={(e) => setSelectedPkgId(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-[#D5CDC1] rounded-xs text-[#1F2124] focus:outline-none focus:border-[#1F2124] font-medium"
            >
              <optgroup label="Wedding / Debut / Baby Shower Packages">
                {WEDDING_PACKAGES.map(pkg => (
                  <option key={pkg.id} value={pkg.id}>
                    {pkg.name} — ₱{pkg.basePrice.toLocaleString()} (Max {pkg.maxScents} Scents)
                  </option>
                ))}
              </optgroup>
              <optgroup label="Stag / Bachelorette Packages">
                <option value={STAG_BACHELORETTE_PACKAGE.id}>
                  {STAG_BACHELORETTE_PACKAGE.name} — ₱{STAG_BACHELORETTE_PACKAGE.basePrice.toLocaleString()}
                </option>
              </optgroup>
              <optgroup label="Special Events Packages (By Pax Tier)">
                {SPECIAL_EVENTS_PACKAGES.map(pkg => (
                  <option key={pkg.id} value={pkg.id}>
                    {pkg.name} ({pkg.subtitle}) — ₱{pkg.basePrice.toLocaleString()}
                  </option>
                ))}
              </optgroup>
            </select>
            
            {/* Quick highlight of chosen tier */}
            <div className="mt-2.5 p-3 bg-white rounded-xs border border-[#E7E0D2] text-xs text-[#5C564D] space-y-1">
              <div className="flex items-center justify-between font-medium text-[#1F2124]">
                <span>{currentPkg.subtitle}</span>
                <span className="font-mono text-[11px] text-[#8A7969]">Max {currentPkg.maxScents} Scents</span>
              </div>
              <p className="text-[11px] font-light leading-relaxed">
                {currentPkg.description}
              </p>
            </div>
          </div>

          {/* Step 2: Add-Ons Configuration */}
          <div>
            <label className="block text-xs tracking-[0.16em] uppercase font-semibold text-[#3D3A34] mb-3">
              02. Select Signature Add-Ons
            </label>

            <div className="space-y-3">
              
              {/* Add-on 1: Bride and Groom Duo */}
              <div className={`p-4 rounded-xs border transition-all ${
                includeBrideGroomDuo ? 'bg-white border-[#1F2124] shadow-xs' : 'bg-[#F5F2EC] border-[#DDD5C7]'
              }`}>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeBrideGroomDuo}
                    onChange={(e) => setIncludeBrideGroomDuo(e.target.checked)}
                    className="mt-1 w-4 h-4 accent-[#1F2124]"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-semibold text-[#1F2124]">
                        Bride & Groom Perfume Duo (2 × 100ml)
                      </span>
                      <span className="text-xs font-mono font-semibold text-[#1F2124]">
                        +₱4,500
                      </span>
                    </div>
                    <p className="text-xs text-[#635D55] font-light mt-0.5">
                      Two 100ml premium heavy-base flacons with personalized coordinates label, vow excerpts, and luxury keepsake box.
                    </p>
                  </div>
                </label>
              </div>

              {/* Add-on 2: Entourage Gift Sets */}
              <div className={`p-4 rounded-xs border transition-all ${
                entourageQty > 0 ? 'bg-white border-[#1F2124] shadow-xs' : 'bg-[#F5F2EC] border-[#DDD5C7]'
              }`}>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-xs sm:text-sm font-semibold text-[#1F2124]">
                      Entourage Gift Sets (50ml)
                    </span>
                    <p className="text-xs text-[#635D55] font-light mt-0.5">
                      Max 2 Scents for Bridesmaids & 2 Scents for Groomsmen. Individual role names on label.
                    </p>
                  </div>
                  <span className="text-xs font-mono font-semibold text-[#1F2124]">
                    ₱680 / bottle
                  </span>
                </div>

                <div className="mt-3 pt-3 border-t border-[#EAE3D6] flex items-center justify-between">
                  <span className="text-xs text-[#524E46]">Quantity of Entourage Bottles:</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setEntourageQty(Math.max(0, entourageQty - 2))}
                      className="w-7 h-7 bg-[#EFEAE0] hover:bg-[#E2DDD3] text-xs font-semibold rounded-xs transition-colors"
                    >
                      -
                    </button>
                    <span className="w-8 text-center text-xs font-mono font-bold">{entourageQty}</span>
                    <button
                      onClick={() => setEntourageQty(entourageQty + 2)}
                      className="w-7 h-7 bg-[#EFEAE0] hover:bg-[#E2DDD3] text-xs font-semibold rounded-xs transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              {/* Add-on 3: Wax Seal & Silk Ribbon */}
              <div className={`p-4 rounded-xs border transition-all ${
                includeWaxSealRibbon ? 'bg-white border-[#1F2124] shadow-xs' : 'bg-[#F5F2EC] border-[#DDD5C7]'
              }`}>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeWaxSealRibbon}
                    onChange={(e) => setIncludeWaxSealRibbon(e.target.checked)}
                    className="mt-1 w-4 h-4 accent-[#1F2124]"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-semibold text-[#1F2124]">
                        Custom Monogram Wax Seal & Hand-Tied Silk Ribbon
                      </span>
                      <span className="text-xs font-mono font-semibold text-[#1F2124]">
                        +₱1,500
                      </span>
                    </div>
                    <p className="text-xs text-[#635D55] font-light mt-0.5">
                      Applied to all individual boxes matching your wedding or debut monogram stamp.
                    </p>
                  </div>
                </label>
              </div>

            </div>
          </div>

          {/* Live Price Summary Box */}
          <div className="p-5 bg-[#FAF4ED] rounded-xs border border-[#E5DAC8] space-y-2">
            <div className="flex items-center justify-between text-xs text-[#635D54]">
              <span>Base Package ({currentPkg.name})</span>
              <span className="font-mono">₱{basePackageTotal.toLocaleString()}</span>
            </div>

            {includeBrideGroomDuo && (
              <div className="flex items-center justify-between text-xs text-[#635D54]">
                <span>Bride & Groom 100ml Duo</span>
                <span className="font-mono">₱{brideGroomTotal.toLocaleString()}</span>
              </div>
            )}

            {entourageQty > 0 && (
              <div className="flex items-center justify-between text-xs text-[#635D54]">
                <span>Entourage Bottles ({entourageQty} pcs)</span>
                <span className="font-mono">₱{entourageTotal.toLocaleString()}</span>
              </div>
            )}

            {includeWaxSealRibbon && (
              <div className="flex items-center justify-between text-xs text-[#635D54]">
                <span>Wax Seal & Ribbon Finishing</span>
                <span className="font-mono">₱{waxSealTotal.toLocaleString()}</span>
              </div>
            )}

            <div className="pt-2 border-t border-[#DFD1BD] flex items-baseline justify-between">
              <span className="text-xs tracking-[0.16em] uppercase font-semibold text-[#1F2124]">
                Estimated Total:
              </span>
              <div className="flex items-baseline gap-1">
                <span className="text-xs text-[#787268] font-mono">PHP</span>
                <span className="text-2xl sm:text-3xl font-serif-title font-bold text-[#1F2124] tabular-nums">
                  ₱{grandTotal.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 sm:p-6 bg-white border-t border-[#E8E2D6] flex flex-col sm:flex-row items-center justify-between gap-3">
          
          <button
            onClick={handleCopyQuote}
            className="w-full sm:w-auto px-4 py-2.5 bg-white border border-[#D5CDC1] hover:border-[#1F2124] text-xs tracking-[0.14em] uppercase font-semibold text-[#1F2124] rounded-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            {copiedToast ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedToast ? 'Quote Copied to Clipboard!' : 'Copy Formal Estimate'}</span>
          </button>

          <button
            onClick={() => {
              onProceedToInquiry(generateQuoteText());
            }}
            className="w-full sm:w-auto px-6 py-2.5 bg-[#1F2124] hover:bg-[#343840] text-xs tracking-[0.16em] uppercase font-semibold text-white rounded-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#E5C5C2]" />
            <span>Proceed to Book / Inquire</span>
          </button>

        </div>

      </div>
    </div>
  );
};
