export interface PackageTier {
  id: string;
  name: string;
  category: 'wedding-debut' | 'stag-bachelorette' | 'special-events';
  subtitle: string;
  description: string;
  badge?: string;
  maxScents: number;
  features: string[];
  basePrice: number;
  idealFor: string;
  minPax?: number;
  maxPax?: number;
  includesFaceToFace?: boolean;
  discoverySetCount?: number;
}

export interface AddOnItem {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  features: string[];
  price: number;
  unit: string;
  iconName: string;
}

export interface ScentNote {
  id: string;
  name: string;
  category: 'Floral' | 'Woody' | 'Citrus & Fresh' | 'Gourmand & Warm' | 'Aquatic' | 'Oriental & Amber';
  description: string;
  topNotes: string[];
  heartNotes: string[];
  baseNotes: string[];
  vibe: string;
}

export interface CustomBottleState {
  labelTitle: string; // e.g. "MARCO & SOFIA" or "TOKYO"
  eventDateOrCity: string; // e.g. "MANILA, PHILIPPINES"
  coordinatesText: string; // e.g. "14° 35' 31.2\" N 120° 58' 55.4\" E"
  selectedScents: string[];
  capStyle: 'matte-black' | 'pearl-white' | 'champagne-gold';
  paletteTheme: 'sakura-pink' | 'pearl-white' | 'stone-greige' | 'mist-blue' | 'ink-black';
  bottleVolume: '50ml' | '100ml';
}

export interface QuoteSelection {
  selectedPackageId: string;
  paxCount: number;
  includeBrideGroomDuo: boolean;
  entourageGiftQty: number; // number of entourage sets/bottles
  customRibbonAndSeal: boolean;
  rushDelivery: boolean;
  notes: string;
}
